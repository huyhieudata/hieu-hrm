import { useNavigate } from 'react-router-dom';
import { ArrowRight, Building2, LogOut } from 'lucide-react';
import Logo from '../components/Logo';
import { WORKSPACES } from '../data/session';

export default function Workspaces() {
  const nav = useNavigate();
  return (
    <div className="ws-page">
      <header className="ws-head">
        <Logo />
        <a className="btn-ghost" href="#/auth/login">
          <LogOut size={14} />
          Đăng xuất
        </a>
      </header>

      <div style={{ textAlign: 'center', marginTop: 24 }}>
        <span className="pill"><i />Không gian làm việc</span>
      </div>
      <h1>Chọn công ty của bạn</h1>
      <p className="muted center">Bạn đang là thành viên của {WORKSPACES.length} công ty</p>

      <div className="ws-grid">
        {WORKSPACES.map(w => (
          <button
            key={w.id}
            type="button"
            className="ws-card"
            onClick={() => { localStorage.setItem('ws', w.id); nav('/select-apps'); }}
          >
            <div
              className="ws-avatar"
              style={{ background: `linear-gradient(135deg, ${w.color}, ${w.color}cc)` }}
            >
              {w.name.split(' ').filter(Boolean).map(x => x[0]).slice(0, 2).join('')}
            </div>
            <div className="ws-info">
              <b>{w.name}</b>
              <span className="role">Super Admin</span>
            </div>
            <span className="arrow"><ArrowRight size={16} /></span>
          </button>
        ))}
      </div>

      <div className="ws-foot">
        <Building2 size={12} style={{ display: 'inline', verticalAlign: -1, marginRight: 5 }} />
        Cần truy cập công ty khác? Liên hệ quản trị viên hệ thống.
      </div>
    </div>
  );
}
