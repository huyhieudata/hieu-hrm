import { useState, type CSSProperties } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Mail, Phone, UserRound, Lock, Eye, EyeOff, ArrowRight, Globe, ChevronDown,
  ShieldCheck, Sparkles, Star, Building2,
} from 'lucide-react';
import Logo from '../components/Logo';
import { useToast } from '../components/feedback';

const TABS = [
  { label: 'Email', icon: Mail, placeholder: 'minhanh.nguyen@nova.vn', type: 'email' },
  { label: 'Số điện thoại', icon: Phone, placeholder: '0901 224 778', type: 'tel' },
  { label: 'Tên đăng nhập', icon: UserRound, placeholder: 'minhanh.nguyen', type: 'text' },
];

const NODES = [
  { label: 'Hồ sơ nhân sự', x: 50, y: 10, dot: '#2563EB', delay: '0s' },
  { label: 'Chấm công', x: 83.3, y: 28, dot: '#7C6CF0', delay: '.6s' },
  { label: 'Tính lương', x: 83.3, y: 72, dot: '#0D9488', delay: '1.2s' },
  { label: 'Đánh giá', x: 50, y: 90, dot: '#D97706', delay: '1.8s' },
  { label: 'Tuyển dụng', x: 16.7, y: 72, dot: '#DB2777', delay: '2.4s' },
  { label: 'Đơn từ', x: 16.7, y: 28, dot: '#2563EB', delay: '3s' },
];

const GoogleIcon = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
    <path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.2-2.27H12v4.51h6.47a5.54 5.54 0 0 1-2.4 3.63v3h3.86c2.26-2.09 3.56-5.17 3.56-8.87Z" />
    <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09A11.99 11.99 0 0 0 12 24Z" />
    <path fill="#FBBC05" d="M5.27 14.29a7.2 7.2 0 0 1 0-4.58V6.62H1.29a12 12 0 0 0 0 10.76l3.98-3.09Z" />
    <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.7 0 3.99 2.47 1.29 6.62l3.98 3.09C6.22 6.86 8.87 4.75 12 4.75Z" />
  </svg>
);

const MicrosoftIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true">
    <path fill="#F25022" d="M2 2h9.5v9.5H2z" />
    <path fill="#7FBA00" d="M12.5 2H22v9.5h-9.5z" />
    <path fill="#00A4EF" d="M2 12.5h9.5V22H2z" />
    <path fill="#FFB900" d="M12.5 12.5H22V22h-9.5z" />
  </svg>
);

const AppleIcon = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true">
    <path d="M16.36 12.72c.02 2.4 2.1 3.2 2.13 3.21-.02.06-.33 1.14-1.1 2.25-.66.97-1.35 1.94-2.43 1.96-1.06.02-1.4-.63-2.62-.63-1.21 0-1.6.61-2.6.65-1.04.04-1.83-1.04-2.5-2.01-1.37-1.98-2.42-5.6-1.01-8.04.7-1.21 1.95-1.98 3.3-2 1.02-.02 1.99.69 2.62.69.62 0 1.8-.85 3.04-.72.52.02 1.97.21 2.9 1.58-.08.05-1.74 1.02-1.72 3.05ZM14.45 3.6c.56-.68.94-1.63.84-2.58-.82.03-1.8.55-2.38 1.23-.52.6-.97 1.56-.85 2.48.9.07 1.83-.46 2.39-1.13Z" />
  </svg>
);

export default function Login() {
  const nav = useNavigate();
  const toast = useToast();
  const [tab, setTab] = useState(0);
  const [show, setShow] = useState(false);
  const active = TABS[tab];
  const ActiveIcon = active.icon;

  return (
    <div className="login">
      <section className="login-left">
        <div className="login-brand-row">
          <Logo />
          <span className="login-version"><Sparkles size={12} /> Phiên bản 4.2</span>
        </div>

        <div className="login-copy">
          <h1>
            Nền tảng quản trị<br />nhân sự <span>hiệu suất cao</span>
          </h1>
          <p className="login-desc">
            Số hóa toàn bộ quy trình nhân sự — hồ sơ, chấm công, tính lương, đánh giá — trong một
            không gian làm việc duy nhất, dành cho doanh nghiệp Việt.
          </p>
        </div>

        <div className="login-orbit">
          <svg className="orbit-svg" viewBox="0 0 420 300" aria-hidden="true">
            <circle cx="210" cy="150" r="118" fill="none" stroke="rgba(37,99,235,.12)" strokeDasharray="2 6" />
            <circle cx="210" cy="150" r="78" fill="none" stroke="rgba(37,99,235,.10)" />
            {NODES.map(n => (
              <line
                key={n.label}
                x1="210"
                y1="150"
                x2={(n.x / 100) * 420}
                y2={(n.y / 100) * 300}
                stroke="rgba(37,99,235,.26)"
                strokeWidth="1.2"
                strokeDasharray="4 5"
              />
            ))}
          </svg>

          <div className="orbit-center">
            <span className="logo-mark" style={{ width: 62, height: 62, borderRadius: 18 }}>
              <svg width="30" height="30" viewBox="0 0 24 24" fill="none">
                <path d="M6.5 5.5v13M17.5 5.5v13M6.5 12h11" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" />
              </svg>
            </span>
          </div>

          {NODES.map(n => (
            <div
              key={n.label}
              className="orbit-node"
              style={{ left: `${n.x}%`, top: `${n.y}%`, animationDelay: n.delay, '--dot': n.dot } as CSSProperties}
            >
              <i /> {n.label}
            </div>
          ))}
        </div>

        <div className="login-quote">
          <p>
            “Chúng tôi rút ngắn 70% thời gian xử lý bảng lương mỗi tháng và không còn sai sót
            chấm công.”
          </p>
          <div className="login-quote-row">
            <div className="av" style={{ width: 30, height: 30 }}>TH</div>
            <div className="login-quote-meta">
              <b>Trần Thu Hương</b>
              <span>Giám đốc Vận hành · An Phát Group</span>
            </div>
            <div className="stars">
              {[0, 1, 2, 3, 4].map(s => <Star key={s} size={12} fill="currentColor" />)}
            </div>
          </div>
        </div>

        <div className="login-proof">
          <span><i />2.500+ doanh nghiệp tin dùng</span>
          <span><ShieldCheck size={12} />ISO 27001 · Bảo mật dữ liệu</span>
          <span><Building2 size={12} />Quản trị tập trung đa công ty</span>
        </div>
      </section>

      <section className="login-right">
        <div className="login-topbar">
          <div className="lang-pill">
            <Globe size={13} />VIE<ChevronDown size={12} />
          </div>
          <button
            type="button"
            className="login-help"
            onClick={() => toast('Bộ phận hỗ trợ sẽ liên hệ trong 15 phút làm việc.')}
          >
            Cần hỗ trợ?
          </button>
        </div>

        <div className="login-center">
          <form className="login-form" onSubmit={e => { e.preventDefault(); nav('/workspaces'); }}>
            <div className="login-logo">
              <span className="logo-mark" style={{ width: 34, height: 34, borderRadius: 10 }}>
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                  <path d="M6.5 5.5v13M17.5 5.5v13M6.5 12h11" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" />
                </svg>
              </span>
            </div>

            <h2>Đăng nhập</h2>
            <p className="muted">Chào mừng bạn quay trở lại. Tiếp tục quản lý đội ngũ của bạn.</p>

            <div className="tabs" role="tablist">
              {TABS.map((t, i) => (
                <button
                  key={t.label}
                  type="button"
                  role="tab"
                  aria-selected={i === tab}
                  className={i === tab ? 'on' : ''}
                  onClick={() => setTab(i)}
                >
                  {t.label}
                </button>
              ))}
            </div>

            <label htmlFor="login-id">{active.label}</label>
            <div className="field-wrap">
              <ActiveIcon size={16} />
              <input
                id="login-id"
                type={active.type}
                placeholder={active.placeholder}
                autoComplete="username"
              />
            </div>

            <label htmlFor="login-password">Mật khẩu</label>
            <div className="pw">
              <div className="field-wrap">
                <Lock size={16} />
                <input
                  id="login-password"
                  type={show ? 'text' : 'password'}
                  placeholder="Nhập mật khẩu"
                  autoComplete="current-password"
                  defaultValue="novahrm2026"
                />
              </div>
              <button
                type="button"
                className="pw-toggle"
                onClick={() => setShow(!show)}
                aria-label={show ? 'Ẩn mật khẩu' : 'Hiện mật khẩu'}
              >
                {show ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>

            <div className="row-between">
              <label className="chk">
                <input type="checkbox" defaultChecked /> Ghi nhớ đăng nhập
              </label>
              <button
                type="button"
                className="link"
                style={{ background: 'none', border: 0, fontSize: 12.5, fontWeight: 500 }}
                onClick={() => toast('Liên kết đặt lại mật khẩu đã được gửi tới email của bạn.')}
              >
                Quên mật khẩu?
              </button>
            </div>

            <button className="btn-primary big" type="submit">
              Đăng nhập
              <ArrowRight size={16} />
            </button>

            <div className="divider"><span>hoặc tiếp tục bằng</span></div>

            <div className="sso">
              <button type="button" onClick={() => nav('/workspaces')}>
                <GoogleIcon /> Google
              </button>
              <button type="button" onClick={() => nav('/workspaces')}>
                <MicrosoftIcon /> Microsoft
              </button>
              <button type="button" onClick={() => nav('/workspaces')}>
                <AppleIcon /> Apple
              </button>
            </div>

            <p className="login-demo">Bản demo giao diện — nhập bất kỳ thông tin để đăng nhập.</p>

            <p className="login-signup">
              Chưa có tài khoản?{' '}
              <button type="button" onClick={() => toast('Vui lòng liên hệ quản trị viên để được cấp tài khoản.')}>
                Liên hệ quản trị viên
              </button>
            </p>
          </form>
        </div>

        <div className="login-foot">
          <span>© 2026 HRM Hub</span>
          <div>
            <a href="#/auth/login">Bảo mật</a>
            <a href="#/auth/login">Điều khoản</a>
            <a href="#/auth/login">Trạng thái hệ thống</a>
          </div>
        </div>
      </section>
    </div>
  );
}
