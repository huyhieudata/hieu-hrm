import { NavLink, Outlet, useNavigate, useParams, Navigate } from 'react-router-dom';
import { useEffect, useRef, useState } from 'react';
import {
  Menu, X, Search, Bell, Moon, Sun, Grid2X2, ChevronDown, LifeBuoy,
} from 'lucide-react';
import { MODULES, getModule } from '../data/menu';
import { plain } from '../data/text';
import { USER, currentWs } from '../data/session';
import { useTheme } from './useTheme';
import Logo from './Logo';
import { ModuleIcon } from './ModuleIcon';

export default function ModuleLayout() {
  const { moduleId } = useParams();
  const nav = useNavigate();
  const mod = getModule(moduleId);
  const [dark, toggle] = useTheme();
  const ref = useRef<HTMLInputElement>(null);
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        ref.current?.focus();
      }
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);

  useEffect(() => { setOpen(false); setQ(''); }, [moduleId]);

  if (!mod) return <Navigate to="/select-apps" replace />;

  const results = q
    ? MODULES.flatMap(m => m.sub.map(s => ({ m, s })))
        .filter(x => plain(x.m.label + ' ' + x.s.label).includes(plain(q)))
        .slice(0, 8)
    : [];
  const ws = currentWs();

  return (
    <div className={'shell' + (open ? ' menu-open' : '')}>
      <aside className="rail" aria-label="Phân hệ">
        <button type="button" className="rail-item" onClick={() => nav('/select-apps')} title="Tất cả ứng dụng">
          <span className="ri"><Grid2X2 size={19} strokeWidth={1.9} /></span>
          <small>Tất cả</small>
        </button>
        <div className="rail-sep" />
        {MODULES.map(m => (
          <NavLink
            key={m.id}
            to={`/m/${m.id}`}
            className={() => 'rail-item' + (m.id === mod.id ? ' active' : '')}
            title={m.label}
          >
            <span className="ri"><ModuleIcon id={m.id} size={19} /></span>
            <small>{m.label}</small>
          </NavLink>
        ))}
      </aside>

      <div className="mobile-scrim" onClick={() => setOpen(false)} aria-hidden="true" />

      <aside className="subnav" aria-label="Danh mục">
        <div className="subnav-modules">
          {MODULES.map(m => (
            <NavLink
              key={m.id}
              to={`/m/${m.id}`}
              className={() => (m.id === mod.id ? 'active' : '')}
              onClick={() => setOpen(false)}
            >
              <ModuleIcon id={m.id} size={18} />
              <span>{m.label}</span>
            </NavLink>
          ))}
        </div>

        <div className="subnav-title">
          <span
            className="module-tile"
            style={{ background: mod.color + '1F', color: mod.color }}
          >
            <ModuleIcon id={mod.id} size={18} />
          </span>
          <div style={{ minWidth: 0 }}>
            {mod.label}
            <small>{mod.sub.length} mục quản lý</small>
          </div>
          <button
            type="button"
            className="icon-btn"
            style={{ marginLeft: 'auto' }}
            onClick={() => setOpen(false)}
            aria-label="Đóng menu"
          >
            <X size={16} />
          </button>
        </div>

        <nav className="subnav-scroll">
          {mod.sub.map(s => (
            <NavLink
              key={s.id}
              end={s.id === 'overview'}
              to={`/m/${mod.id}/${s.id === 'overview' ? '' : s.id}`}
              className={({ isActive }) => 'sub-item' + (isActive ? ' active' : '')}
              onClick={() => setOpen(false)}
            >
              {s.label}
            </NavLink>
          ))}
        </nav>

        <div className="subnav-foot">
          <button
            type="button"
            className="btn-ghost"
            style={{ width: '100%', justifyContent: 'flex-start' }}
            onClick={() => nav('/select-apps')}
          >
            <Grid2X2 size={15} />
            Tất cả ứng dụng
          </button>
        </div>
      </aside>

      <div className="main">
        <header className="topbar">
          <button type="button" className="menu-btn" onClick={() => setOpen(true)} aria-label="Mở menu điều hướng">
            <Menu size={18} />
          </button>

          <div className="tb-brand">
            <Logo />
          </div>

          <button type="button" className="tb-ws" onClick={() => nav('/workspaces')} title="Đổi không gian làm việc">
            <span className="ws-dot">{ws.name.slice(0, 2).toUpperCase()}</span>
            <span>
              <small>Không gian làm việc</small>
              <b>{ws.name}</b>
            </span>
            <ChevronDown size={13} />
          </button>

          <div className="tb-search">
            <Search size={15} />
            <input
              ref={ref}
              value={q}
              onChange={e => setQ(e.target.value)}
              onBlur={() => setTimeout(() => setQ(''), 160)}
              placeholder="Tìm chức năng, nhân sự, mã…"
              aria-label="Tìm kiếm chức năng"
            />
            <kbd>Ctrl K</kbd>
            {results.length > 0 && (
              <div className="tb-results">
                {results.map(r => (
                  <button
                    key={r.m.id + r.s.id}
                    type="button"
                    onMouseDown={() => nav(`/m/${r.m.id}/${r.s.id === 'overview' ? '' : r.s.id}`)}
                  >
                    <ModuleIcon id={r.m.id} size={15} />
                    <span>{r.s.label}</span>
                    <span className="res-mod">{r.m.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="hdr-right dark-text">
            <button type="button" className="pill" title="Ngôn ngữ">VIE</button>
            <button type="button" className="ico" onClick={toggle} title="Chuyển giao diện sáng/tối">
              {dark ? <Sun size={16} /> : <Moon size={16} />}
            </button>
            <button type="button" className="ico" title="Thông báo">
              <Bell size={16} />
              <i className="badge">12</i>
            </button>
            <button type="button" className="ico tb-help" title="Trợ giúp" onClick={() => nav('/workspaces')}>
              <LifeBuoy size={16} />
            </button>
            <div className="tb-divider" />
            <div className="user-chip" style={{ background: 'transparent', border: 0, padding: 0 }}>
              <div className="av" style={{ width: 34, height: 34 }}>{USER.initials}</div>
              <div style={{ whiteSpace: 'nowrap' }}>
                <b>{USER.name}</b>
                <small>{USER.title}</small>
              </div>
              <ChevronDown size={13} style={{ color: 'var(--mu)' }} />
            </div>
          </div>
        </header>

        <div className="content">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
