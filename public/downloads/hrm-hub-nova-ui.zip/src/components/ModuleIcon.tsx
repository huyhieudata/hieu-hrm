import type { LucideIcon } from 'lucide-react';
import {
  LayoutDashboard, Users, FileText, Fingerprint, Wallet, Star, ListChecks, Briefcase,
  Lightbulb, FolderOpen, PenLine, Megaphone, UserRound, Settings, CalendarDays, Clock3,
  Building2, ShieldCheck, Banknote, Files, Gem, ClipboardList, Bookmark, BadgeCheck,
  Sparkles, FolderKanban, Boxes, Inbox, KeyRound, Newspaper, CircleUserRound, ReceiptText,
  ContactRound, ArrowLeftRight, ScrollText, Award, TrendingUp, PieChart, Target,
} from 'lucide-react';

const MODULE: Record<string, LucideIcon> = {
  overview: LayoutDashboard,
  'nhan-su': Users,
  'don-tu': FileText,
  'cham-cong': Fingerprint,
  'tinh-luong': Wallet,
  'danh-gia': Star,
  'cong-viec': ListChecks,
  'tai-san': Briefcase,
  'de-xuat': Lightbulb,
  'tai-lieu': FolderOpen,
  'ky-so': PenLine,
  'truyen-thong': Megaphone,
  'ca-nhan': UserRound,
  'he-thong': Settings,
};

const APP_ICON_RULES: Array<[RegExp, LucideIcon]> = [
  [/nhân sự/i, Users],
  [/đơn từ/i, FileText],
  [/chấm công|bảng công/i, Fingerprint],
  [/tính lương|bảng lương|lương/i, Wallet],
  [/quyết định/i, ScrollText],
  [/đánh giá|kpi/i, Star],
  [/công việc/i, ListChecks],
  [/tài sản/i, Briefcase],
  [/đề xuất/i, Lightbulb],
  [/tài liệu/i, FolderOpen],
  [/ký số|chữ ký/i, PenLine],
  [/hệ thống|cài đặt|cấu hình|thiết lập/i, Settings],
  [/thông tin công ty|công ty|chi nhánh|đơn vị|phòng ban/i, Building2],
  [/thông tin cá nhân|cá nhân|tài khoản/i, UserRound],
  [/danh bạ|liên hệ/i, ContactRound],
  [/hợp đồng/i, Files],
  [/bảo hiểm|bhxh/i, ShieldCheck],
  [/khen thưởng|thâm niên/i, Award],
  [/kỷ luật/i, BadgeCheck],
  [/báo cáo|thống kê/i, PieChart],
  [/nghỉ phép|ngày phép|phép/i, CalendarDays],
  [/chấm công|đi trễ|vắng/i, Clock3],
  [/tuyển dụng|ứng viên/i, Target],
  [/đào tạo|chứng chỉ/i, Gem],
  [/tài chính|thanh toán|chi phí/i, Banknote],
  [/tin tức|thông báo|truyền thông|mạng nội bộ/i, Newspaper],
  [/đổi mật khẩu|mật khẩu|đăng nhập/i, KeyRound],
  [/danh mục|biểu mẫu/i, ClipboardList],
  [/dự án/i, FolderKanban],
  [/tích hợp|api|business rule/i, Boxes],
  [/gói dịch vụ/i, ReceiptText],
  [/phê duyệt|cần duyệt|duyệt/i, Inbox],
  [/thống kê|tăng trưởng/i, TrendingUp],
  [/ghi chú|bookmark/i, Bookmark],
  [/spark|ai/i, Sparkles],
];

export function moduleIcon(id?: string): LucideIcon {
  return (id && MODULE[id]) || LayoutDashboard;
}

export function appIcon(label: string): LucideIcon {
  return APP_ICON_RULES.find(([rule]) => rule.test(label))?.[1] || CircleUserRound;
}

interface Props {
  id?: string;
  label?: string;
  size?: number;
  strokeWidth?: number;
  className?: string;
}

export function ModuleIcon({ id, label, size = 18, strokeWidth = 1.9, className }: Props) {
  const Icon: LucideIcon = id ? moduleIcon(id) : appIcon(label ?? '');
  return <Icon size={size} strokeWidth={strokeWidth} className={className} aria-hidden="true" />;
}

export function AppIcon({ label, size = 28, strokeWidth = 1.7, className }: Omit<Props, 'id'>) {
  const Icon: LucideIcon = appIcon(label ?? '');
  return <Icon size={size} strokeWidth={strokeWidth} className={className} aria-hidden="true" />;
}
