export default function Logo({ light }: { light?: boolean }) {
  return (
    <div className="logo">
      <span className="logo-mark" aria-hidden="true">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
          <path d="M6.5 5.5v13M17.5 5.5v13M6.5 12h11" stroke="#fff" strokeWidth="2.3" strokeLinecap="round" />
        </svg>
      </span>
      <span style={{ color: light ? '#FFFFFF' : undefined }}>
        HRM <b style={{ color: light ? '#93C5FD' : undefined }}>Hub</b>
      </span>
    </div>
  );
}
