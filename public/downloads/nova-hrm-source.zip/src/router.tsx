import { lazy, type ReactNode } from "react";

import { RequireAuth, RequireCompany } from "./components/auth/route-guards";
import { PageSuspense } from "./components/layout/page-suspense";
import NotFound from "./pages/NotFound";

const Index = lazy(() => import("./pages/Index"));
const Login = lazy(() => import("./pages/Login"));
const Employees = lazy(() => import("./pages/Employees"));
const Attendance = lazy(() => import("./pages/Attendance"));
const Leave = lazy(() => import("./pages/Leave"));
const Payroll = lazy(() => import("./pages/Payroll"));
const Team = lazy(() => import("./pages/Team"));
const CompanyPicker = lazy(() => import("./pages/CompanyPicker"));
const JoinCompany = lazy(() => import("./pages/JoinCompany"));

const authenticated = (node: ReactNode) => <RequireAuth>{node}</RequireAuth>;

const companyScoped = (node: ReactNode) => (
  <RequireAuth>
    <RequireCompany>{node}</RequireCompany>
  </RequireAuth>
);

export const routers = [
  {
    path: "/",
    name: "dashboard",
    element: companyScoped(
      <PageSuspense>
        <Index />
      </PageSuspense>,
    ),
  },
  {
    path: "/login",
    name: "login",
    element: (
      <PageSuspense>
        <Login />
      </PageSuspense>
    ),
  },
  {
    path: "/employees",
    name: "employees",
    element: companyScoped(
      <PageSuspense>
        <Employees />
      </PageSuspense>,
    ),
  },
  {
    path: "/attendance",
    name: "attendance",
    element: companyScoped(
      <PageSuspense>
        <Attendance />
      </PageSuspense>,
    ),
  },
  {
    path: "/leave",
    name: "leave",
    element: companyScoped(
      <PageSuspense>
        <Leave />
      </PageSuspense>,
    ),
  },
  {
    path: "/payroll",
    name: "payroll",
    element: companyScoped(
      <PageSuspense>
        <Payroll />
      </PageSuspense>,
    ),
  },
  {
    path: "/doi-ngu",
    name: "team",
    element: companyScoped(
      <PageSuspense>
        <Team />
      </PageSuspense>,
    ),
  },
  {
    path: "/cong-ty",
    name: "company-picker",
    element: authenticated(
      <PageSuspense>
        <CompanyPicker />
      </PageSuspense>,
    ),
  },
  {
    path: "/tham-gia/:token",
    name: "join-company",
    element: authenticated(
      <PageSuspense>
        <JoinCompany />
      </PageSuspense>,
    ),
  },
  /* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */
  {
    path: "*",
    name: "404",
    element: <NotFound />,
  },
];

declare global {
  interface Window {
    __routers__: typeof routers;
  }
}

window.__routers__ = routers;
