import { useMemo, useState } from "react";
import {
  ArrowDownToLine,
  Banknote,
  CheckCircle2,
  ChevronDown,
  CircleDollarSign,
  Download,
  FileText,
  MoreHorizontal,
  Plus,
  Search,
  Send,
  ShieldCheck,
  Wallet,
} from "lucide-react";
import { toast } from "sonner";

import { AppShell } from "@/components/layout/app-shell";
import { Avatar, StatusPill } from "@/components/common/avatar";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { payrollRows, type PayrollRow } from "@/data/hrm";
import { currency } from "@/lib/format";
import { cn } from "@/lib/utils";

const statusInfo: Record<PayrollRow["status"], { label: string; tone: "success" | "info" | "muted" }> = {
  paid: { label: "Đã chi trả", tone: "success" },
  processing: { label: "Chờ phát hành", tone: "info" },
  draft: { label: "Bản nháp", tone: "muted" },
};

const steps = [
  { label: "Tạo kỳ lương", meta: "01/10 · Hoàn tất", state: "done" },
  { label: "Rà soát & đối chiếu", meta: "28/10 · Đang thực hiện", state: "current" },
  { label: "Phê duyệt của Ban điều hành", meta: "Dự kiến 30/10", state: "next" },
  { label: "Phát hành phiếu lương", meta: "Dự kiến 31/10", state: "next" },
];

const Payroll = () => {
  const [query, setQuery] = useState("");

  const rows = useMemo(
    () =>
      payrollRows.filter((row) =>
        `${row.name} ${row.department} ${row.position}`.toLowerCase().includes(query.toLowerCase()),
      ),
    [query],
  );

  const totals = rows.reduce(
    (acc, row) => ({
      base: acc.base + row.base,
      allowance: acc.allowance + row.allowance,
      deduction: acc.deduction + row.deduction,
      net: acc.net + row.base + row.allowance - row.deduction,
    }),
    { base: 0, allowance: 0, deduction: 0, net: 0 },
  );

  return (
    <AppShell>
      <PageHeader
        eyebrow="Tài chính"
        title="Bảng lương"
        description="Kỳ lương tháng 10/2026 · 248 phiếu lương · hạn chốt 30/10/2026."
        actions={
          <>
            <Button variant="outline" size="sm" className="h-9 gap-2 text-[12.5px]">
              <Download className="h-3.5 w-3.5" />
              Xuất phiếu lương
            </Button>
            <Button size="sm" className="h-9 gap-1.5 text-[12.5px]">
              <Plus className="h-4 w-4" />
              Tạo kỳ lương
            </Button>
          </>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="relative col-span-1 overflow-hidden rounded-xl bg-brand p-6 text-primary-foreground shadow-primary-glow lg:col-span-2">
          <div className="pointer-events-none absolute inset-0 opacity-[0.18] bg-grid" />
          <div className="pointer-events-none absolute -right-12 -top-16 h-56 w-56 rounded-full bg-primary-foreground/20 blur-2xl" />
          <div className="pointer-events-none absolute -bottom-16 right-24 h-40 w-40 rounded-full bg-chart-5/30 blur-2xl" />

          <div className="relative flex flex-wrap items-start justify-between gap-4">
            <div>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-primary-foreground/15 px-2.5 py-1 text-[10.5px] font-semibold uppercase tracking-[0.1em]">
                <span className="h-1.5 w-1.5 rounded-full bg-primary-foreground" />
                Kỳ lương tháng 10/2026
              </span>
              <p className="mt-4 text-[12px] font-medium text-primary-foreground/80">
                Tổng chi trả dự kiến
              </p>
              <div className="mt-1 flex flex-wrap items-end gap-2">
                <span className="tabular font-display text-[38px] font-semibold leading-none tracking-[-0.03em]">
                  3,84
                </span>
                <span className="pb-1 text-[15px] font-medium text-primary-foreground/85">tỷ đồng</span>
                <span className="mb-1 ml-1 inline-flex items-center gap-0.5 rounded-full bg-primary-foreground/15 px-2 py-0.5 text-[10.5px] font-semibold">
                  +1,1% so với tháng 9
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => toast.success("Đã gửi 62 phiếu lương còn lại", { description: "Nhân sự sẽ nhận thông báo qua email." })}
              className="inline-flex h-10 items-center gap-2 rounded-md bg-primary-foreground px-4 text-[12.5px] font-semibold text-primary shadow-raised transition-transform hover:-translate-y-0.5"
            >
              <Send className="h-4 w-4" />
              Phát hành phiếu lương
            </button>
          </div>

          <div className="relative mt-6 grid gap-3 sm:grid-cols-3">
            {[
              { label: "Lương cơ bản", value: "2,96 tỷ", icon: Banknote },
              { label: "Phụ cấp & thưởng", value: "1,19 tỷ", icon: CircleDollarSign },
              { label: "Khấu trừ & thuế", value: "0,31 tỷ", icon: ShieldCheck },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.label}
                  className="rounded-lg border border-primary-foreground/15 bg-primary-foreground/10 p-3 backdrop-blur-sm"
                >
                  <div className="flex items-center gap-1.5 text-[10.5px] font-medium text-primary-foreground/75">
                    <Icon className="h-3.5 w-3.5" />
                    {item.label}
                  </div>
                  <p className="tabular mt-1 text-[17px] font-semibold leading-6">{item.value}</p>
                </div>
              );
            })}
          </div>

          <div className="relative mt-5">
            <div className="flex items-center justify-between text-[11px] font-medium text-primary-foreground/85">
              <span>Đã phát hành 186/248 phiếu lương</span>
              <span className="tabular">75%</span>
            </div>
            <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-primary-foreground/20">
              <div className="h-full w-3/4 rounded-full bg-primary-foreground" />
            </div>
          </div>
        </div>

        <Card className="col-span-1 flex flex-col overflow-hidden">
          <div className="flex items-start justify-between gap-3 px-5 pb-3 pt-5">
            <div>
              <h3 className="text-[15px] font-semibold leading-6 text-foreground">Tiến độ kỳ lương</h3>
              <p className="mt-0.5 text-[12px] text-muted-foreground">4 bước · còn 3 ngày</p>
            </div>
            <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-primary-subtle text-primary">
              <Wallet className="h-[18px] w-[18px]" strokeWidth={1.9} />
            </span>
          </div>

          <ol className="px-5 pb-4 pt-1">
            {steps.map((step, index) => (
              <li key={step.label} className="relative flex gap-3 pb-4 last:pb-0">
                {index !== steps.length - 1 && (
                  <span
                    className={cn(
                      "absolute left-[9px] top-5 h-[calc(100%-14px)] w-px",
                      step.state === "done" ? "bg-success/40" : "bg-border",
                    )}
                  />
                )}
                <span
                  className={cn(
                    "relative mt-0.5 flex h-[19px] w-[19px] shrink-0 items-center justify-center rounded-full border",
                    step.state === "done" && "border-success bg-success text-primary-foreground",
                    step.state === "current" && "border-primary bg-primary-subtle",
                    step.state === "next" && "border-border bg-card",
                  )}
                >
                  {step.state === "done" ? (
                    <CheckCircle2 className="h-3 w-3" />
                  ) : (
                    <span
                      className={cn(
                        "h-1.5 w-1.5 rounded-full",
                        step.state === "current" ? "bg-primary" : "bg-muted-foreground/40",
                      )}
                    />
                  )}
                </span>
                <div className="min-w-0 flex-1 pt-0.5">
                  <p
                    className={cn(
                      "text-[12.5px] font-medium leading-4",
                      step.state === "next" ? "text-muted-foreground" : "text-foreground",
                    )}
                  >
                    {step.label}
                  </p>
                  <p className="mt-0.5 text-[10.5px] text-muted-foreground">{step.meta}</p>
                </div>
              </li>
            ))}
          </ol>

          <div className="mt-auto border-t border-border bg-muted/30 px-5 py-3">
            <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <ShieldCheck className="h-3.5 w-3.5 text-success" />
              Dữ liệu lương được mã hóa và giới hạn quyền truy cập.
            </p>
          </div>
        </Card>
      </div>

      <Card className="overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-border/80 p-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-[15px] font-semibold leading-6 text-foreground">Chi tiết bảng lương</h3>
            <span className="rounded-full bg-muted px-2 py-0.5 text-[10.5px] font-medium text-muted-foreground">
              {rows.length} phiếu
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                type="search"
                placeholder="Tìm nhân viên…"
                className="h-9 w-[210px] rounded-md border border-input bg-card pl-8 pr-3 text-[12px] text-foreground outline-none transition-all placeholder:text-muted-foreground/80 hover:border-primary/30 focus:border-primary focus:shadow-focus"
              />
            </div>
            <button
              type="button"
              className="flex h-9 items-center gap-1.5 rounded-md border border-border bg-card px-3 text-[12px] font-medium text-foreground shadow-xs transition-colors hover:bg-muted"
            >
              <FileText className="h-3.5 w-3.5 text-muted-foreground" />
              Tất cả phòng ban
              <ChevronDown className="h-3 w-3 text-muted-foreground" />
            </button>
            <Button variant="outline" size="sm" className="h-9 gap-1.5 text-[12px]">
              <ArrowDownToLine className="h-3.5 w-3.5" />
              CSV
            </Button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[1010px] border-collapse text-left">
            <thead>
              <tr className="border-b border-border/80 bg-muted/40">
                <th scope="col" className="h-11 whitespace-nowrap px-4 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                  Nhân viên
                </th>
                <th scope="col" className="h-11 whitespace-nowrap px-4 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                  Phòng ban
                </th>
                <th scope="col" className="h-11 whitespace-nowrap px-4 text-right text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                  Lương cơ bản
                </th>
                <th scope="col" className="h-11 whitespace-nowrap px-4 text-right text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                  Phụ cấp
                </th>
                <th scope="col" className="h-11 whitespace-nowrap px-4 text-right text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                  Khấu trừ
                </th>
                <th scope="col" className="h-11 whitespace-nowrap px-4 text-right text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                  Thực nhận
                </th>
                <th scope="col" className="h-11 whitespace-nowrap px-4 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                  Trạng thái
                </th>
                <th scope="col" className="h-11 w-12" />
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => {
                const info = statusInfo[row.status];
                const net = row.base + row.allowance - row.deduction;
                return (
                  <tr key={row.id} className="border-b border-border/60 transition-colors last:border-0 hover:bg-primary/[0.03]">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <Avatar name={row.name} size="md" />
                        <div className="min-w-0">
                          <p className="truncate text-[13px] font-medium leading-5 text-foreground">{row.name}</p>
                          <p className="truncate text-[11px] text-muted-foreground">{row.position}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center whitespace-nowrap rounded-full bg-muted px-2 py-1 text-[11px] font-medium text-muted-foreground">
                        {row.department}
                      </span>
                    </td>
                    <td className="tabular px-4 py-3 text-right text-[12.5px] text-foreground">{currency(row.base)}</td>
                    <td className="tabular px-4 py-3 text-right text-[12.5px] text-success">+{currency(row.allowance)}</td>
                    <td className="tabular px-4 py-3 text-right text-[12.5px] text-destructive">−{currency(row.deduction)}</td>
                    <td className="tabular px-4 py-3 text-right text-[13px] font-semibold text-foreground">{currency(net)}</td>
                    <td className="px-4 py-3">
                      <StatusPill tone={info.tone} label={info.label} />
                    </td>
                    <td className="px-3 py-3 text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button
                            type="button"
                            aria-label={`Tác vụ lương ${row.name}`}
                            className="flex h-8 w-8 items-center justify-center rounded-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-[190px] rounded-lg shadow-overlay">
                          <DropdownMenuItem className="gap-2.5">
                            <FileText className="h-4 w-4" /> Xem phiếu lương
                          </DropdownMenuItem>
                          <DropdownMenuItem className="gap-2.5">
                            <Send className="h-4 w-4" /> Gửi cho nhân viên
                          </DropdownMenuItem>
                          <DropdownMenuItem className="gap-2.5">
                            <Download className="h-4 w-4" /> Tải PDF
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="gap-2.5"
                            onSelect={() => toast.success("Đã đánh dấu đã chi trả", { description: row.name })}
                          >
                            <CheckCircle2 className="h-4 w-4" /> Đánh dấu đã chi trả
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="border-t border-border bg-muted/40">
                <td className="px-4 py-3 text-[11.5px] font-semibold uppercase tracking-[0.06em] text-muted-foreground" colSpan={2}>
                  Tổng cộng ({rows.length} phiếu hiển thị)
                </td>
                <td className="tabular px-4 py-3 text-right text-[12.5px] font-semibold text-foreground">{currency(totals.base)}</td>
                <td className="tabular px-4 py-3 text-right text-[12.5px] font-semibold text-success">+{currency(totals.allowance)}</td>
                <td className="tabular px-4 py-3 text-right text-[12.5px] font-semibold text-destructive">−{currency(totals.deduction)}</td>
                <td className="tabular px-4 py-3 text-right text-[13px] font-semibold text-primary">{currency(totals.net)}</td>
                <td className="px-4 py-3" />
                <td className="px-3 py-3" />
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border/80 px-4 py-3">
          <p className="text-[11.5px] text-muted-foreground">
            Bảng lương tạm tính, chưa bao gồm thưởng KPI quý IV.
          </p>
          <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-success" />
              Đã đối chiếu với dữ liệu chấm công
            </span>
          </div>
        </div>
      </Card>
    </AppShell>
  );
};

export default Payroll;
