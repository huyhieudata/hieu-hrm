import { useState, type FormEvent } from "react";
import {
  CalendarDays,
  CalendarPlus,
  Check,
  ChevronRight,
  Clock3,
  Info,
  Palmtree,
  Settings2,
  Sparkles,
  X,
} from "lucide-react";
import { toast } from "sonner";

import { AppShell } from "@/components/layout/app-shell";
import { Avatar, StatusPill } from "@/components/common/avatar";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { leaveBalance, leaveRequests, type LeaveRequest } from "@/data/hrm";
import { cn } from "@/lib/utils";

const tabs = [
  { id: "pending", label: "Chờ duyệt" },
  { id: "approved", label: "Đã duyệt" },
  { id: "rejected", label: "Từ chối" },
  { id: "all", label: "Tất cả" },
] as const;

const typeTone: Record<string, "primary" | "info" | "warning" | "muted"> = {
  "Phép năm": "primary",
  "Nghỉ ốm": "info",
  "Việc riêng": "warning",
  "Nghỉ bù": "muted",
};

const summary = [
  { label: "Số dư phép của tôi", value: "12", unit: "/ 18 ngày", tone: "text-primary", bars: 67 },
  { label: "Đơn chờ duyệt", value: "3", unit: "đơn", tone: "text-warning", bars: 30 },
  { label: "Đã duyệt tháng này", value: "8", unit: "đơn", tone: "text-success", bars: 50 },
  { label: "Ngày vắng mặt", value: "4", unit: "ngày", tone: "text-info", bars: 22 },
];

const Leave = () => {
  const [items, setItems] = useState<LeaveRequest[]>(leaveRequests);
  const [tab, setTab] = useState<(typeof tabs)[number]["id"]>("pending");
  const [open, setOpen] = useState(false);
  const [type, setType] = useState("Phép năm");
  const [from, setFrom] = useState("2026-11-02");
  const [to, setTo] = useState("2026-11-04");
  const [reason, setReason] = useState("");

  const filtered = tab === "all" ? items : items.filter((item) => item.status === tab);
  const pendingCount = items.filter((item) => item.status === "pending").length;

  const countFor = (id: (typeof tabs)[number]["id"]) =>
    id === "all" ? items.length : items.filter((item) => item.status === id).length;

  const handle = (id: string, approve: boolean) => {
    const target = items.find((item) => item.id === id);
    if (!target) return;
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, status: approve ? "approved" : "rejected" } : item,
      ),
    );
    if (approve) {
      toast.success("Đã duyệt đơn nghỉ phép", { description: `${target.name} · ${target.days} ngày` });
    } else {
      toast.error("Đã từ chối đơn nghỉ phép", { description: `${target.name} · ${target.days} ngày` });
    }
  };

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const days =
      Math.max(
        0,
        Math.round(
          (new Date(to).getTime() - new Date(from).getTime()) / (1000 * 60 * 60 * 24),
        ) + 1,
      ) || 1;
    const format = (value: string) => value.split("-").reverse().join("/");

    setItems((prev) => [
      {
        id: `l-${Date.now()}`,
        name: "Nguyễn Minh Anh",
        department: "Nhân sự",
        type,
        from: format(from),
        to: format(to),
        days,
        reason: reason || "Việc cá nhân",
        submitted: "Vừa xong",
        status: "pending",
      },
      ...prev,
    ]);
    setOpen(false);
    setReason("");
    setTab("pending");
    toast.success("Đã gửi đơn nghỉ phép", {
      description: `${type} · ${days} ngày, đang chờ quản lý duyệt.`,
    });
  };

  return (
    <AppShell>
      <PageHeader
        eyebrow="Nhân sự"
        title="Nghỉ phép"
        description="Theo dõi đơn từ, số dư phép và lịch nghỉ của đội ngũ trong một nơi duy nhất."
        actions={
          <>
            <Button variant="outline" size="sm" className="h-9 gap-2 text-[12.5px]">
              <Settings2 className="h-3.5 w-3.5" />
              Chính sách nghỉ phép
            </Button>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="h-9 gap-1.5 text-[12.5px]">
                  <CalendarPlus className="h-4 w-4" />
                  Tạo đơn nghỉ phép
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[460px]">
                <DialogHeader>
                  <DialogTitle>Tạo đơn nghỉ phép</DialogTitle>
                  <DialogDescription>
                    Đơn sẽ được gửi tới quản lý trực tiếp và cập nhật vào số dư phép ngay khi được duyệt.
                  </DialogDescription>
                </DialogHeader>

                <form onSubmit={submit} className="space-y-4">
                  <div className="space-y-1.5">
                    <label htmlFor="leave-type" className="text-[12.5px] font-medium text-foreground">
                      Loại nghỉ phép
                    </label>
                    <div className="relative">
                      <select
                        id="leave-type"
                        value={type}
                        onChange={(event) => setType(event.target.value)}
                        className="h-11 w-full appearance-none rounded-md border border-input bg-card px-3 pr-9 text-[13px] text-foreground outline-none transition-colors hover:border-primary/30 focus:border-primary"
                      >
                        {["Phép năm", "Nghỉ ốm", "Việc riêng", "Nghỉ bù", "Thai sản"].map((option) => (
                          <option key={option}>{option}</option>
                        ))}
                      </select>
                      <ChevronRight className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 rotate-90 text-muted-foreground" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label htmlFor="from" className="text-[12.5px] font-medium text-foreground">
                        Từ ngày
                      </label>
                      <Input id="from" type="date" value={from} onChange={(event) => setFrom(event.target.value)} required />
                    </div>
                    <div className="space-y-1.5">
                      <label htmlFor="to" className="text-[12.5px] font-medium text-foreground">
                        Đến ngày
                      </label>
                      <Input id="to" type="date" value={to} onChange={(event) => setTo(event.target.value)} required />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label htmlFor="reason" className="text-[12.5px] font-medium text-foreground">
                      Lý do
                    </label>
                    <textarea
                      id="reason"
                      value={reason}
                      onChange={(event) => setReason(event.target.value)}
                      rows={3}
                      placeholder="Mô tả ngắn gọn lý do nghỉ phép…"
                      className="w-full resize-none rounded-md border border-input bg-card px-3 py-2.5 text-[13px] leading-5 text-foreground outline-none transition-all placeholder:text-muted-foreground/80 hover:border-primary/30 focus:border-primary focus:shadow-focus"
                    />
                  </div>

                  <div className="flex items-start gap-2.5 rounded-md border border-primary/15 bg-primary-subtle/60 px-3 py-2.5">
                    <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                    <p className="text-[11.5px] leading-5 text-primary-subtle-foreground">
                      Người duyệt: <span className="font-semibold">Trần Thu Hương</span> · Bạn còn{" "}
                      <span className="font-semibold">12 ngày phép</span> trong năm 2026.
                    </p>
                  </div>

                  <DialogFooter className="gap-2 pt-1">
                    <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                      Hủy
                    </Button>
                    <Button type="submit" className="gap-1.5">
                      <Check className="h-4 w-4" />
                      Gửi đơn
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {summary.map((item, index) => (
          <Card
            key={item.label}
            className={cn("animate-fade-up p-5", index === 1 && "animation-delay-100", index === 2 && "animation-delay-200", index === 3 && "animation-delay-300")}
          >
            <p className="text-[12.5px] text-muted-foreground">{item.label}</p>
            <div className="mt-1.5 flex items-baseline gap-1.5">
              <span className={cn("tabular font-display text-[26px] font-semibold leading-8", item.tone)}>
                {item.value}
              </span>
              <span className="text-[11.5px] text-muted-foreground">{item.unit}</span>
            </div>
            <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-muted">
              <div className="h-full rounded-full bg-brand" style={{ width: `${item.bars}%` }} />
            </div>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="col-span-1 self-start overflow-hidden lg:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/80 px-5 py-4">
            <div className="flex items-center gap-2">
              <h3 className="text-[15px] font-semibold leading-6 text-foreground">Danh sách đơn từ</h3>
              <span className="tabular flex h-5 min-w-5 items-center justify-center rounded-full bg-warning-subtle px-1.5 text-[10.5px] font-semibold text-warning">
                {pendingCount} chờ
              </span>
            </div>
            <div className="flex items-center gap-0.5 rounded-md border border-border bg-muted/50 p-0.5">
              {tabs.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTab(item.id)}
                  className={cn(
                    "rounded-[7px] px-2.5 py-1.5 text-[11.5px] font-medium transition-all",
                    tab === item.id
                      ? "bg-card font-semibold text-foreground shadow-xs"
                      : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {item.label}
                  <span className="ml-1 text-[10px] text-muted-foreground">{countFor(item.id)}</span>
                </button>
              ))}
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 px-6 py-16 text-center">
              <span className="flex h-11 w-11 items-center justify-center rounded-full bg-muted text-muted-foreground">
                <Palmtree className="h-5 w-5" />
              </span>
              <p className="text-[13px] font-semibold text-foreground">Không có đơn nào</p>
              <p className="text-[12px] text-muted-foreground">Mọi đơn trong mục này đã được xử lý.</p>
            </div>
          ) : (
            <ul className="divide-y divide-border/70">
              {filtered.map((item) => (
                <li key={item.id} className="flex flex-col gap-3 px-5 py-4 transition-colors hover:bg-muted/30 sm:flex-row sm:items-center">
                  <div className="flex min-w-0 flex-1 items-start gap-3">
                    <Avatar name={item.name} size="lg" />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                        <p className="truncate text-[13px] font-semibold text-foreground">{item.name}</p>
                        <span className="text-[11px] text-muted-foreground">· {item.department}</span>
                        <StatusPill
                          label={item.type}
                          tone={typeTone[item.type] ?? "muted"}
                          dot={false}
                          className="px-2 py-0 text-[10px]"
                        />
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11.5px] text-muted-foreground">
                        <span className="inline-flex items-center gap-1">
                          <CalendarDays className="h-3 w-3" />
                          {item.from} – {item.to}
                        </span>
                        <span className="tabular font-medium text-foreground/80">{item.days} ngày</span>
                        <span className="inline-flex items-center gap-1 text-muted-foreground/80">
                          <Clock3 className="h-3 w-3" />
                          {item.submitted}
                        </span>
                      </div>
                      <p className="mt-1 line-clamp-2 text-[11.5px] italic text-muted-foreground/90">
                        “{item.reason}”
                      </p>
                    </div>
                  </div>

                  {item.status === "pending" ? (
                    <div className="flex shrink-0 items-center gap-1.5 pl-12 sm:pl-0">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 gap-1 px-2.5 text-destructive hover:bg-destructive-subtle hover:text-destructive"
                        onClick={() => handle(item.id, false)}
                      >
                        <X className="h-3.5 w-3.5" />
                        Từ chối
                      </Button>
                      <Button size="sm" className="h-8 gap-1 px-2.5" onClick={() => handle(item.id, true)}>
                        <Check className="h-3.5 w-3.5" />
                        Duyệt
                      </Button>
                    </div>
                  ) : (
                    <div className="shrink-0 pl-12 sm:pl-0">
                      <StatusPill
                        tone={item.status === "approved" ? "success" : "destructive"}
                        label={item.status === "approved" ? "Đã duyệt" : "Từ chối"}
                      />
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}

          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border bg-muted/30 px-5 py-3">
            <p className="text-[11.5px] text-muted-foreground">
              Đơn được duyệt sẽ tự động trừ vào số dư phép năm.
            </p>
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-primary">
              Lịch sử đơn từ
              <ChevronRight className="h-3 w-3" />
            </span>
          </div>
        </Card>

        <div className="col-span-1 space-y-4">
          <Card className="overflow-hidden">
            <div className="flex items-start justify-between gap-3 px-5 pb-3 pt-5">
              <div>
                <h3 className="text-[15px] font-semibold leading-6 text-foreground">Số dư phép</h3>
                <p className="mt-0.5 text-[12px] text-muted-foreground">Năm 2026 · cập nhật hôm nay</p>
              </div>
              <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-chart-3/12 text-chart-3">
                <Palmtree className="h-[18px] w-[18px]" strokeWidth={1.9} />
              </span>
            </div>

            <ul className="space-y-3.5 px-5 pb-5 pt-1">
              {leaveBalance.map((person) => {
                const remaining = person.total - person.used;
                return (
                  <li key={person.name}>
                    <div className="mb-1.5 flex items-center justify-between text-[12px]">
                      <span className="flex items-center gap-2">
                        <Avatar name={person.name} size="sm" />
                        <span className="font-medium text-foreground">{person.name}</span>
                      </span>
                      <span className="tabular text-muted-foreground">
                        <span className="font-semibold text-foreground">{remaining}</span>/{person.total}
                      </span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                      <div
                        className="h-full rounded-full bg-chart-3"
                        style={{ width: `${(person.used / person.total) * 100}%` }}
                      />
                    </div>
                  </li>
                );
              })}
            </ul>
            <div className="border-t border-border bg-muted/30 px-5 py-3">
              <button type="button" className="flex w-full items-center justify-between text-[11.5px] font-semibold text-primary">
                Xem toàn bộ số dư
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </Card>

          <div className="relative overflow-hidden rounded-xl border border-primary/15 bg-panel p-5 shadow-card">
            <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-primary/10 blur-xl" />
            <div className="relative">
              <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-card text-primary shadow-soft">
                <Sparkles className="h-[18px] w-[18px]" strokeWidth={1.9} />
              </span>
              <h4 className="mt-3 font-display text-[14px] font-semibold text-foreground">
                Tự động nhắc lịch nghỉ
              </h4>
              <p className="mt-1 text-[11.5px] leading-5 text-muted-foreground">
                Nova AI sẽ nhắc quản lý khi có đơn chờ quá 24 giờ và gợi ý người thay thế phù hợp.
              </p>
              <button
                type="button"
                className="mt-3 inline-flex items-center gap-1.5 rounded-md bg-card px-3 py-1.5 text-[11.5px] font-semibold text-primary shadow-xs transition-shadow hover:shadow-soft"
              >
                Bật nhắc nhở
                <ChevronRight className="h-3 w-3" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
};

export default Leave;
