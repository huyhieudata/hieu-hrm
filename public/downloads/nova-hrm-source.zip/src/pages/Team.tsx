import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  AlertCircle,
  Copy,
  Crown,
  Link2,
  LogOut,
  Mail,
  MoreHorizontal,
  Search,
  ShieldCheck,
  Trash2,
  UserMinus,
  UserPlus,
  Users,
} from "lucide-react";
import { toast } from "sonner";

import { AppShell } from "@/components/layout/app-shell";
import { Avatar } from "@/components/common/avatar";
import { PageHeader } from "@/components/common/page-header";
import { InviteDialog } from "@/components/team/invite-dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { copyInviteLink } from "@/lib/invite-link";
import { useAuth } from "@/lib/auth-provider";
import { useCompany } from "@/lib/company-provider";
import {
  ASSIGNABLE_ROLES,
  ROLE_BADGE,
  ROLE_DESCRIPTIONS,
  ROLE_LABELS,
  ROLE_ORDER,
  type Role,
} from "@/lib/roles";
import { cn } from "@/lib/utils";

interface TeamMember {
  id: string;
  user_id: string;
  role: Role;
  status: string;
  job_title: string | null;
  department: string | null;
  joined_at: string;
  full_name: string | null;
  email: string | null;
}

interface InviteRow {
  id: string;
  token: string;
  email: string | null;
  role: Role;
  job_title: string | null;
  department: string | null;
  expires_at: string;
  created_at: string;
}

interface ProfileRow {
  id: string;
  full_name: string | null;
  email: string | null;
  job_title: string | null;
}

const formatDay = (value: string) =>
  new Date(value).toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric" });

const Team = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { activeCompany, role, can, refreshMemberships, memberships, setActiveCompany } = useCompany();
  const companyId = activeCompany?.id ?? null;

  const [members, setMembers] = useState<TeamMember[]>([]);
  const [invites, setInvites] = useState<InviteRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [inviteOpen, setInviteOpen] = useState(false);
  const [removal, setRemoval] = useState<TeamMember | null>(null);
  const [leaving, setLeaving] = useState(false);

  const canManage = can("members.manage");
  const canInvite = can("members.invite");
  const canSeeInvites = canInvite;
  const isOwner = role === "owner";

  const load = useCallback(async () => {
    if (!companyId) return;
    setLoading(true);
    try {
      const { data: memberRows, error: memberError } = await supabase
        .from("company_members")
        .select("id, user_id, role, status, job_title, department, joined_at")
        .eq("company_id", companyId)
        .order("joined_at", { ascending: true });

      if (memberError) throw memberError;

      const userIds = (memberRows ?? []).map((row) => row.user_id);
      const profilesById = new Map<string, ProfileRow>();

      if (userIds.length > 0) {
        const { data: profileRows, error: profileError } = await supabase
          .from("profiles")
          .select("id, full_name, email, job_title")
          .in("id", userIds);

        if (profileError) throw profileError;
        (profileRows ?? []).forEach((row) => profilesById.set(row.id, row));
      }

      setMembers(
        (memberRows ?? []).map((row) => {
          const person = profilesById.get(row.user_id);
          return {
            id: row.id,
            user_id: row.user_id,
            role: row.role as Role,
            status: row.status,
            job_title: row.job_title,
            department: row.department,
            joined_at: row.joined_at,
            full_name: person?.full_name ?? null,
            email: person?.email ?? null,
          };
        }),
      );

      if (canSeeInvites) {
        const { data: inviteRows, error: inviteError } = await supabase
          .from("company_invites")
          .select("id, token, email, role, job_title, department, expires_at, created_at")
          .eq("company_id", companyId)
          .eq("revoked", false)
          .is("accepted_at", null)
          .order("created_at", { ascending: false });

        if (inviteError) throw inviteError;
        setInvites((inviteRows ?? []).map((row) => ({ ...row, role: row.role as Role })));
      } else {
        setInvites([]);
      }
    } catch (error) {
      console.error("Không tải được danh sách thành viên", error);
      toast.error("Không tải được đội ngũ", { description: "Vui lòng thử lại sau." });
    } finally {
      setLoading(false);
    }
  }, [canSeeInvites, companyId]);

  useEffect(() => {
    void load();
  }, [load]);

  const filtered = useMemo(() => {
    const keyword = query.trim().toLowerCase();
    if (!keyword) return members;
    return members.filter((member) =>
      `${member.full_name ?? ""} ${member.email ?? ""} ${member.department ?? ""} ${member.job_title ?? ""} ${ROLE_LABELS[member.role]}`
        .toLowerCase()
        .includes(keyword),
    );
  }, [members, query]);

  const stats = useMemo(
    () => ({
      total: members.length,
      active: members.filter((member) => member.status === "active").length,
      invites: invites.length,
      admins: members.filter((member) => member.role === "owner" || member.role === "admin").length,
    }),
    [invites.length, members],
  );

  const roleCounts = useMemo(() => {
    const counts: Record<Role, number> = { owner: 0, admin: 0, hr: 0, manager: 0, employee: 0 };
    members.forEach((member) => {
      counts[member.role] += 1;
    });
    return counts;
  }, [members]);

  const changeRole = async (member: TeamMember, nextRole: Role) => {
    if (member.role === nextRole) return;
    const { error } = await supabase
      .from("company_members")
      .update({ role: nextRole })
      .eq("id", member.id);

    if (error) {
      toast.error("Không đổi được vai trò", {
        description: error.message.includes("row-level security")
          ? "Bạn không có quyền thay đổi vai trò này."
          : error.message,
      });
      return;
    }

    toast.success("Đã cập nhật vai trò", {
      description: `${member.full_name ?? member.email ?? "Thành viên"} → ${ROLE_LABELS[nextRole]}`,
    });
    void load();
  };

  const removeMember = async () => {
    if (!removal) return;
    const { error } = await supabase.from("company_members").delete().eq("id", removal.id);

    if (error) {
      toast.error("Không xoá được thành viên", {
        description: error.message.includes("row-level security")
          ? "Bạn không có quyền xoá thành viên này."
          : error.message,
      });
      return;
    }

    toast.success("Đã xoá thành viên khỏi công ty");
    setRemoval(null);
    void load();
  };

  const revokeInvite = async (invite: InviteRow) => {
    const { error } = await supabase.from("company_invites").update({ revoked: true }).eq("id", invite.id);
    if (error) {
      toast.error("Không thu hồi được lời mời");
      return;
    }
    toast.success("Đã thu hồi lời mời");
    void load();
  };

  const leaveCompany = async () => {
    const membership = memberships.find((item) => item.company_id === companyId);
    if (!membership) return;

    setLeaving(true);
    const { error } = await supabase.from("company_members").delete().eq("id", membership.id);
    setLeaving(false);

    if (error) {
      toast.error("Không thể rời công ty", { description: error.message });
      return;
    }

    toast.success("Bạn đã rời công ty");
    await refreshMemberships();
    const next = memberships.find((item) => item.company_id !== companyId);
    if (next) setActiveCompany(next.company_id);
    navigate(next ? "/" : "/cong-ty");
  };

  const currentRole = role ?? "employee";

  return (
    <AppShell>
      <PageHeader
        eyebrow="Quản trị công ty"
        title="Đội ngũ & phân quyền"
        description={`${activeCompany?.name ?? "Công ty"} · Vai trò của bạn là ${ROLE_LABELS[currentRole]}. Quản lý thành viên, lời mời và quyền truy cập dữ liệu.`}
        actions={
          <>
            {canInvite && (
              <Button className="h-9 gap-2 text-[12.5px]" onClick={() => setInviteOpen(true)}>
                <UserPlus className="h-4 w-4" />
                Mời thành viên
              </Button>
            )}
            {currentRole !== "owner" && (
              <Button
                variant="outline"
                className="h-9 gap-2 text-[12.5px]"
                onClick={() => void leaveCompany()}
                disabled={leaving}
              >
                <LogOut className="h-3.5 w-3.5" />
                Rời công ty
              </Button>
            )}
          </>
        }
      />

      <div className="grid gap-3.5 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Tổng thành viên", value: stats.total, icon: Users, tone: "primary" },
          { label: "Đang hoạt động", value: stats.active, icon: ShieldCheck, tone: "success" },
          { label: "Lời mời chờ", value: stats.invites, icon: Link2, tone: "info" },
          { label: "Quản trị viên", value: stats.admins, icon: Crown, tone: "warning" },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <Card key={item.label} className="flex items-center gap-3 p-4">
              <span
                className={cn(
                  "flex h-10 w-10 items-center justify-center rounded-[11px]",
                  item.tone === "primary" && "bg-primary-subtle text-primary-subtle-foreground",
                  item.tone === "success" && "bg-success-subtle text-success",
                  item.tone === "info" && "bg-info-subtle text-info",
                  item.tone === "warning" && "bg-warning-subtle text-warning",
                )}
              >
                <Icon className="h-[18px] w-[18px]" strokeWidth={1.9} />
              </span>
              <div>
                <p className="text-[11px] font-medium uppercase tracking-[0.1em] text-muted-foreground">
                  {item.label}
                </p>
                <p className="font-display text-[22px] font-semibold leading-7 tracking-[-0.02em] text-foreground">
                  {loading ? "—" : item.value}
                </p>
              </div>
            </Card>
          );
        })}
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.7fr_1fr]">
        <Card className="overflow-hidden p-0">
          <div className="flex flex-col gap-3 border-b border-border/70 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-[14px] font-semibold text-foreground">Thành viên</h2>
              <p className="text-[11.5px] text-muted-foreground">
                {filtered.length} / {members.length} thành viên
              </p>
            </div>
            <label className="relative block">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <input
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Tìm theo tên, email, phòng ban…"
                className="h-9 w-full rounded-md border border-border bg-card pl-8 pr-3 text-[12.5px] text-foreground shadow-xs outline-none transition-all placeholder:text-muted-foreground/80 hover:border-primary/30 focus:border-primary focus:shadow-focus sm:w-[280px]"
              />
            </label>
          </div>

          <div className="hidden items-center gap-3 border-b border-border/60 bg-muted/30 px-5 py-2.5 text-[10.5px] font-semibold uppercase tracking-[0.1em] text-muted-foreground md:flex">
            <span className="flex-1">Thành viên</span>
            <span className="w-[130px] shrink-0">Vai trò</span>
            <span className="w-[110px] shrink-0">Tham gia</span>
            <span className="w-9 shrink-0" />
          </div>

          {loading ? (
            <div className="px-5 py-10 text-center text-[12.5px] text-muted-foreground">Đang tải đội ngũ…</div>
          ) : filtered.length === 0 ? (
            <div className="px-5 py-12 text-center">
              <AlertCircle className="mx-auto h-6 w-6 text-muted-foreground" />
              <p className="mt-2 text-[13px] font-semibold text-foreground">Không tìm thấy thành viên</p>
              <p className="mt-1 text-[12px] text-muted-foreground">Thử từ khoá khác hoặc mời thêm người.</p>
            </div>
          ) : (
            <ul className="divide-y divide-border/60">
              {filtered.map((member) => {
                const isSelf = member.user_id === user?.id;
                const name = member.full_name || member.email?.split("@")[0] || "Thành viên";
                const roleLocked =
                  !canManage || isSelf || (member.role === "owner" && !isOwner);

                return (
                  <li
                    key={member.id}
                    className="flex items-center gap-3 px-5 py-3 transition-colors hover:bg-muted/30"
                  >
                    <div className="flex min-w-0 flex-1 items-center gap-3">
                      <Avatar name={name} />
                      <div className="min-w-0">
                        <p className="flex items-center gap-1.5 truncate text-[13px] font-semibold text-foreground">
                          <span className="truncate">{name}</span>
                          {isSelf && (
                            <span className="shrink-0 rounded-full bg-muted px-1.5 py-0.5 text-[9.5px] font-semibold uppercase tracking-wide text-muted-foreground">
                              Bạn
                            </span>
                          )}
                        </p>
                        <p className="flex items-center gap-1.5 truncate text-[11.5px] text-muted-foreground">
                          <Mail className="h-3 w-3 shrink-0" />
                          <span className="truncate">{member.email ?? "Chưa có email"}</span>
                        </p>
                        {(member.job_title || member.department) && (
                          <p className="mt-0.5 truncate text-[11px] text-muted-foreground/90">
                            {[member.job_title, member.department].filter(Boolean).join(" · ")}
                          </p>
                        )}
                        <span className="mt-1 inline-flex md:hidden">
                          <Badge variant={ROLE_BADGE[member.role]}>{ROLE_LABELS[member.role]}</Badge>
                        </span>
                      </div>
                    </div>

                    <div className="hidden w-[130px] shrink-0 md:block">
                      {roleLocked ? (
                        <Badge variant={ROLE_BADGE[member.role]}>{ROLE_LABELS[member.role]}</Badge>
                      ) : (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button
                              type="button"
                              className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-2.5 py-1 text-[11px] font-semibold text-foreground shadow-xs transition-colors hover:border-primary/30 hover:bg-primary-subtle"
                            >
                              <span
                                className={cn(
                                  "h-1.5 w-1.5 rounded-full",
                                  member.role === "owner" && "bg-primary",
                                  member.role === "admin" && "bg-chart-2",
                                  member.role === "hr" && "bg-info",
                                  member.role === "manager" && "bg-warning",
                                  member.role === "employee" && "bg-muted-foreground",
                                )}
                              />
                              {ROLE_LABELS[member.role]}
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="start" className="w-[220px]">
                            <DropdownMenuLabel className="text-[10.5px] uppercase tracking-[0.1em] text-muted-foreground">
                              Đổi vai trò
                            </DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            {ASSIGNABLE_ROLES.filter((item) => item !== "admin" || isOwner || member.role === "admin").map(
                              (item) => (
                                <DropdownMenuItem
                                  key={item}
                                  className="gap-2 text-[12.5px]"
                                  onSelect={() => void changeRole(member, item)}
                                >
                                  <span className="flex-1">{ROLE_LABELS[item]}</span>
                                  {member.role === item && <span className="text-[10px] text-primary">Hiện tại</span>}
                                </DropdownMenuItem>
                              ),
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </div>

                    <p className="hidden w-[110px] shrink-0 text-[11.5px] text-muted-foreground md:block">
                      {formatDay(member.joined_at)}
                    </p>

                    <div className="flex w-9 shrink-0 justify-end">
                      {canManage && !isSelf ? (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon-sm" aria-label={`Thao tác với ${name}`}>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-[220px]">
                            <DropdownMenuItem
                              className="gap-2 text-[12.5px]"
                              onSelect={() => {
                                if (!member.email) return;
                                void navigator.clipboard
                                  .writeText(member.email)
                                  .then(() => toast.success("Đã sao chép email", { description: member.email ?? "" }))
                                  .catch(() => toast.message(member.email ?? ""));
                              }}
                              disabled={!member.email}
                            >
                              <Copy className="h-3.5 w-3.5" /> Sao chép email
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="gap-2 text-[12.5px] text-destructive focus:bg-destructive-subtle focus:text-destructive"
                              disabled={member.role === "owner" && !isOwner}
                              onSelect={() => setRemoval(member)}
                            >
                              <UserMinus className="h-3.5 w-3.5" /> Xoá khỏi công ty
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      ) : (
                        <span className="text-[11px] text-muted-foreground/60">—</span>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        <div className="space-y-5">
          {canSeeInvites && (
            <Card className="overflow-hidden p-0">
              <div className="flex items-center justify-between border-b border-border/70 px-5 py-4">
                <div>
                  <h2 className="text-[14px] font-semibold text-foreground">Lời mời đang chờ</h2>
                  <p className="text-[11.5px] text-muted-foreground">Hết hạn sau 14 ngày</p>
                </div>
                <Badge variant="muted">{invites.length}</Badge>
              </div>

              {invites.length === 0 ? (
                <div className="px-5 py-8 text-center">
                  <Link2 className="mx-auto h-5 w-5 text-muted-foreground" />
                  <p className="mt-2 text-[12.5px] font-medium text-foreground">Chưa có lời mời nào</p>
                  <p className="mt-1 text-[11.5px] leading-5 text-muted-foreground">
                    Tạo liên kết mời để thêm đồng nghiệp vào công ty.
                  </p>
                </div>
              ) : (
                <ul className="divide-y divide-border/60">
                  {invites.map((invite) => (
                    <li key={invite.id} className="px-5 py-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="truncate text-[12.5px] font-semibold text-foreground">
                            {invite.email ?? "Liên kết công khai"}
                          </p>
                          <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                            <Badge variant={ROLE_BADGE[invite.role]} className="px-1.5 py-0 text-[9.5px]">
                              {ROLE_LABELS[invite.role]}
                            </Badge>
                            <span>Hết hạn {formatDay(invite.expires_at)}</span>
                          </div>
                        </div>
                        <div className="flex shrink-0 items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            aria-label="Sao chép liên kết"
                            onClick={() => void copyInviteLink(invite.token)}
                          >
                            <Copy className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            aria-label="Thu hồi lời mời"
                            className="text-muted-foreground hover:text-destructive"
                            onClick={() => void revokeInvite(invite)}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          )}

          <Card className="p-5">
            <h2 className="text-[14px] font-semibold text-foreground">Vai trò & quyền hạn</h2>
            <p className="mt-1 text-[11.5px] leading-5 text-muted-foreground">
              Quyền hạn được kiểm tra ở máy chủ, không chỉ ẩn trên giao diện.
            </p>
            <ul className="mt-3.5 space-y-3">
              {ROLE_ORDER.map((item) => (
                <li key={item} className="flex gap-2.5">
                  <Badge variant={ROLE_BADGE[item]} className="mt-0.5 h-fit shrink-0 px-2 py-0 text-[10px]">
                    {ROLE_LABELS[item]}
                  </Badge>
                  <div className="min-w-0 flex-1">
                    <p className="text-[11.5px] leading-5 text-muted-foreground">{ROLE_DESCRIPTIONS[item]}</p>
                  </div>
                  <span className="shrink-0 text-[11px] font-semibold text-foreground">{roleCounts[item]}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>

      {companyId && user && (
        <InviteDialog
          open={inviteOpen}
          onOpenChange={setInviteOpen}
          companyId={companyId}
          actorId={user.id}
          onCreated={() => void load()}
        />
      )}

      <AlertDialog open={!!removal} onOpenChange={(open) => !open && setRemoval(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Xoá thành viên khỏi công ty?</AlertDialogTitle>
            <AlertDialogDescription>
              {removal?.full_name ?? removal?.email ?? "Thành viên này"} sẽ mất quyền truy cập dữ liệu
              của {activeCompany?.name}. Họ có thể được mời lại bất cứ lúc nào.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Huỷ</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => void removeMember()}
            >
              Xoá thành viên
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppShell>
  );
};

export default Team;
