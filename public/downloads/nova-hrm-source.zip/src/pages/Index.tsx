import { CalendarRange, ChevronDown, Download, Plus, UserCheck, Users, Wallet, CalendarClock } from "lucide-react";

import { AppShell } from "@/components/layout/app-shell";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { AttendanceToday } from "@/components/dashboard/attendance-today";
import { BirthdaysCard } from "@/components/dashboard/birthdays-card";
import { ActivityCard } from "@/components/dashboard/activity-card";
import { DepartmentBreakdown } from "@/components/dashboard/department-breakdown";
import { HeadcountChart } from "@/components/dashboard/headcount-chart";
import { LeaveApprovals } from "@/components/dashboard/leave-approvals";
import { Button } from "@/components/ui/button";
import { kpiTrend } from "@/data/hrm";
import { displayName, useAuth } from "@/lib/auth-provider";
import { useCompany } from "@/lib/company-provider";

const Dashboard = () => {
  const { profile, user } = useAuth();
  const { activeCompany, role } = useCompany();
  const firstName = displayName(profile, user?.email).split(" ").slice(-1)[0] ?? "bạn";

  return (
    <AppShell>
      <PageHeader
        eyebrow="Bảng điều khiển"
        title={`Chào buổi sáng, ${firstName}`}
        description={
          activeCompany
            ? `Tình hình nhân sự của ${activeCompany.name} hôm nay, Thứ Tư 28/10/2026.${role === "employee" ? "" : " Bạn có 3 đơn nghỉ phép cần phản hồi."}`
            : "Tình hình nhân sự hôm nay, Thứ Tư 28/10/2026."
        }
        actions={
          <>
            <Button variant="outline" size="sm" className="h-9 gap-2 text-[12.5px]">
              <CalendarRange className="h-3.5 w-3.5 text-muted-foreground" />
              Tháng 10, 2026
              <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
            </Button>
            <Button variant="outline" size="sm" className="hidden h-9 gap-2 text-[12.5px] sm:flex">
              <Download className="h-3.5 w-3.5" />
              Xuất báo cáo
            </Button>
            <Button size="sm" className="h-9 gap-1.5 text-[12.5px]">
              <Plus className="h-4 w-4" />
              Thêm nhân viên
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <StatCard
          label="Tổng nhân sự"
          value="248"
          unit="người"
          delta={2.4}
          icon={Users}
          tone="primary"
          data={kpiTrend.headcount}
          style={{ animationDelay: "0ms" }}
          className="animate-fade-up"
        />
        <StatCard
          label="Có mặt hôm nay"
          value="212"
          unit="/ 248"
          delta={1.2}
          icon={UserCheck}
          tone="teal"
          data={kpiTrend.present}
          className="animate-fade-up animation-delay-100"
        />
        <StatCard
          label="Đơn chờ duyệt"
          value="12"
          unit="đơn"
          deltaLabel="3 đơn mới hôm nay"
          icon={CalendarClock}
          tone="amber"
          data={kpiTrend.pending}
          className="animate-fade-up animation-delay-200"
        />
        <StatCard
          label="Quỹ lương tháng 10"
          value="3,84"
          unit="tỷ đồng"
          delta={1.1}
          icon={Wallet}
          tone="violet"
          data={kpiTrend.payroll}
          className="animate-fade-up animation-delay-300"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <HeadcountChart />
        <DepartmentBreakdown />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <AttendanceToday />
        <LeaveApprovals />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <BirthdaysCard />
        <ActivityCard />
      </div>
    </AppShell>
  );
};

export default Dashboard;
