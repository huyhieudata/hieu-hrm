import { useMemo, useState } from "react";
import {
  ArrowUpRight,
  ChevronLeft,
  ChevronRight,
  Download,
  Filter,
  Mail,
  MoreHorizontal,
  Plus,
  Search,
  SlidersHorizontal,
  Trash2,
  Upload,
  UserCog,
  Users,
} from "lucide-react";
import { toast } from "sonner";

import { AppShell } from "@/components/layout/app-shell";
import { Avatar, StatusPill } from "@/components/common/avatar";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { employees, type Employee, type EmployeeStatus } from "@/data/hrm";
import { cn } from "@/lib/utils";

const statusMap: Record<EmployeeStatus, { label: string; tone: "success" | "info" | "warning" }> = {
  active: { label: "Đang làm việc", tone: "success" },
  probation: { label: "Thử việc", tone: "info" },
  leave: { label: "Đang nghỉ phép", tone: "warning" },
};

const statusFilters = [
  { id: "all", label: "Tất cả" },
  { id: "active", label: "Đang làm việc" },
  { id: "probation", label: "Thử việc" },
  { id: "leave", label: "Nghỉ phép" },
] as const;

const PAGE_SIZE = 8;

const Employees = () => {
  const [query, setQuery] = useState("");
  const [department, setDepartment] = useState("all");
  const [status, setStatus] = useState<(typeof statusFilters)[number]["id"]>("all");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<string[]>([]);

  const filtered = useMemo(() => {
    return employees.filter((person) => {
      const matchesQuery = `${person.name} ${person.code} ${person.email} ${person.position}`
        .toLowerCase()
        .includes(query.toLowerCase());
      const matchesDepartment = department === "all" || person.department === department;
      const matchesStatus = status === "all" || person.status === status;
      return matchesQuery && matchesDepartment && matchesStatus;
    });
  }, [query, department, status]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const rows = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  const allSelected = rows.length > 0 && rows.every((row) => selected.includes(row.id));

  const resetPage = () => setPage(1);

  const toggleAll = () => {
    if (allSelected) {
      setSelected((prev) => prev.filter((id) => !rows.some((row) => row.id === id)));
    } else {
      setSelected((prev) => Array.from(new Set([...prev, ...rows.map((row) => row.id)])));
    }
  };

  const toggleRow = (id: string) => {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id],
    );
  };

  const summary = [
    { label: "Tổng nhân sự", value: "248", hint: "+6 trong tháng", tone: "text-foreground" },
    { label: "Đang làm việc", value: "231", hint: "93,1% tổng số", tone: "text-success" },
    { label: "Thử việc", value: "12", hint: "4 hồ sơ sắp chuyển chính thức", tone: "text-info" },
    { label: "Đang nghỉ phép", value: "5", hint: "trong hôm nay", tone: "text-warning" },
  ];

  return (
    <AppShell>
      <PageHeader
        eyebrow="Nhân sự"
        title="Hồ sơ nhân viên"
        description="Quản lý thông tin, hợp đồng và trạng thái làm việc của toàn bộ 248 nhân sự."
        actions={
          <>
            <Button variant="outline" size="sm" className="h-9 gap-2 text-[12.5px]">
              <Upload className="h-3.5 w-3.5" />
              Nhập từ Excel
            </Button>
            <Button variant="outline" size="sm" className="hidden h-9 gap-2 text-[12.5px] sm:flex">
              <Download className="h-3.5 w-3.5" />
              Xuất dữ liệu
            </Button>
            <Button size="sm" className="h-9 gap-1.5 text-[12.5px]">
              <Plus className="h-4 w-4" />
              Thêm nhân viên
            </Button>
          </>
        }
      />

      <Card className="grid grid-cols-2 divide-border/80 lg:grid-cols-4 lg:divide-x">
        {summary.map((item) => (
          <div key={item.label} className="px-5 py-4">
            <p className="text-[11.5px] text-muted-foreground">{item.label}</p>
            <div className="mt-1.5 flex items-baseline gap-2">
              <span className="tabular font-display text-[24px] font-semibold leading-7 text-foreground">
                {item.value}
              </span>
              <span className={cn("text-[10.5px] font-medium", item.tone)}>{item.hint}</span>
            </div>
          </div>
        ))}
      </Card>

      <Card className="overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-border/80 p-4 xl:flex-row xl:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                resetPage();
              }}
              type="search"
              placeholder="Tìm theo tên, mã nhân viên, email hoặc chức danh…"
              className="h-10 w-full rounded-md border border-input bg-card pl-9 pr-3 text-[13px] text-foreground outline-none transition-all placeholder:text-muted-foreground/80 hover:border-primary/30 focus:border-primary focus:shadow-focus"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <select
                value={department}
                onChange={(event) => {
                  setDepartment(event.target.value);
                  resetPage();
                }}
                className="h-10 appearance-none rounded-md border border-border bg-card pl-3 pr-8 text-[12.5px] font-medium text-foreground shadow-xs outline-none transition-colors hover:border-primary/30 focus:border-primary"
              >
                <option value="all">Tất cả phòng ban</option>
                {Array.from(new Set(employees.map((person) => person.department))).map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
              <ChevronRight className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 rotate-90 text-muted-foreground" />
            </div>

            <div className="flex items-center gap-0.5 rounded-md border border-border bg-muted/50 p-0.5">
              {statusFilters.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setStatus(item.id);
                    resetPage();
                  }}
                  className={cn(
                    "rounded-[7px] px-2.5 py-1.5 text-[11.5px] font-medium transition-all",
                    status === item.id
                      ? "bg-card font-semibold text-foreground shadow-xs"
                      : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <Button variant="outline" size="sm" className="h-10 gap-1.5 border-border bg-card px-3 text-[12.5px]">
              <SlidersHorizontal className="h-3.5 w-3.5" />
              Bộ lọc
              <span className="ml-0.5 rounded-full bg-primary-subtle px-1.5 text-[10px] font-semibold text-primary">
                2
              </span>
            </Button>
          </div>
        </div>

        {selected.length > 0 && (
          <div className="flex flex-wrap items-center gap-3 border-b border-border/80 bg-primary-subtle/60 px-4 py-2.5">
            <span className="text-[12px] font-semibold text-primary-subtle-foreground">
              Đã chọn {selected.length} nhân sự
            </span>
            <div className="ml-auto flex items-center gap-2">
              <Button variant="ghost" size="sm" className="h-8 gap-1.5 text-[11.5px]">
                <Mail className="h-3.5 w-3.5" />
                Gửi email
              </Button>
              <Button variant="ghost" size="sm" className="h-8 gap-1.5 text-[11.5px] text-destructive hover:bg-destructive-subtle hover:text-destructive">
                <Trash2 className="h-3.5 w-3.5" />
                Xoá
              </Button>
              <button
                type="button"
                onClick={() => setSelected([])}
                className="text-[11.5px] font-medium text-muted-foreground hover:text-foreground"
              >
                Bỏ chọn
              </button>
            </div>
          </div>
        )}

        <div className="hidden overflow-x-auto lg:block">
          <table className="w-full min-w-[1020px] border-collapse text-left">
            <thead>
              <tr className="border-b border-border/80 bg-muted/40">
                <th scope="col" className="h-11 w-11 pl-4 pr-0">
                  <Checkbox
                    checked={allSelected}
                    onCheckedChange={toggleAll}
                    aria-label="Chọn tất cả"
                    className="h-4 w-4 rounded-[5px] border-input"
                  />
                </th>
                {["Nhân viên", "Phòng ban", "Chức danh", "Trạng thái", "Ngày vào làm", ""].map(
                  (heading, index) => (
                    <th
                      key={`${heading}-${index}`}
                      scope="col"
                      className={cn(
                        "h-11 whitespace-nowrap px-4 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground",
                        heading === "Chức danh" && "hidden xl:table-cell",
                        heading === "Ngày vào làm" && "hidden lg:table-cell",
                      )}
                    >
                      {heading}
                    </th>
                  ),
                )}
              </tr>
            </thead>
            <tbody>
              {rows.map((person: Employee) => {
                const statusInfo = statusMap[person.status];
                return (
                  <tr
                    key={person.id}
                    className={cn(
                      "border-b border-border/60 transition-colors last:border-0 hover:bg-primary/[0.03]",
                      selected.includes(person.id) && "bg-primary/[0.05]",
                    )}
                  >
                    <td className="py-3 pl-4 pr-0">
                      <Checkbox
                        checked={selected.includes(person.id)}
                        onCheckedChange={() => toggleRow(person.id)}
                        aria-label={`Chọn ${person.name}`}
                        className="h-4 w-4 rounded-[5px] border-input"
                      />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <Avatar name={person.name} size="lg" />
                        <div className="min-w-0">
                          <p className="truncate text-[13px] font-medium leading-5 text-foreground">
                            {person.name}
                          </p>
                          <p className="truncate text-[11px] text-muted-foreground">
                            {person.code} · {person.email}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center whitespace-nowrap rounded-full bg-muted px-2 py-1 text-[11px] font-medium text-muted-foreground">
                        {person.department}
                      </span>
                    </td>
                    <td className="hidden whitespace-nowrap px-4 py-3 text-[12.5px] text-foreground/90 xl:table-cell">
                      {person.position}
                    </td>
                    <td className="px-4 py-3">
                      <StatusPill tone={statusInfo.tone} label={statusInfo.label} />
                    </td>
                    <td className="hidden whitespace-nowrap px-4 py-3 text-[12px] text-muted-foreground lg:table-cell">
                      {person.joinedAt}
                    </td>
                    <td className="px-3 py-3 text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button
                            type="button"
                            aria-label={`Tác vụ cho ${person.name}`}
                            className="flex h-8 w-8 items-center justify-center rounded-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-[190px] rounded-lg shadow-overlay">
                          <DropdownMenuItem className="gap-2.5">
                            <ArrowUpRight className="h-4 w-4" /> Xem hồ sơ
                          </DropdownMenuItem>
                          <DropdownMenuItem className="gap-2.5">
                            <UserCog className="h-4 w-4" /> Chỉnh sửa thông tin
                          </DropdownMenuItem>
                          <DropdownMenuItem className="gap-2.5">
                            <Mail className="h-4 w-4" /> Gửi email
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="gap-2.5 text-destructive focus:bg-destructive-subtle focus:text-destructive"
                            onSelect={() => toast.error("Đã chuyển hồ sơ vào lưu trữ", { description: person.name })}
                          >
                            <Trash2 className="h-4 w-4" /> Lưu trữ hồ sơ
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {rows.length === 0 && (
            <div className="flex flex-col items-center justify-center gap-3 px-6 py-16 text-center">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
                <Users className="h-5 w-5" />
              </span>
              <div>
                <p className="text-[13px] font-semibold text-foreground">Không tìm thấy nhân sự phù hợp</p>
                <p className="mt-0.5 text-[12px] text-muted-foreground">
                  Thử từ khóa khác hoặc xóa bộ lọc phòng ban.
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setQuery("");
                  setDepartment("all");
                  setStatus("all");
                }}
              >
                Xóa bộ lọc
              </Button>
            </div>
          )}
        </div>

        <div className="divide-y divide-border/70 lg:hidden">
          {rows.map((person) => {
            const info = statusMap[person.status];
            return (
              <div key={person.id} className="flex items-start gap-3 px-4 py-3.5 transition-colors active:bg-muted/40">
                <Avatar name={person.name} size="lg" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-[13px] font-semibold text-foreground">{person.name}</p>
                      <p className="truncate text-[11px] text-muted-foreground">
                        {person.code} · {person.department}
                      </p>
                    </div>
                    <StatusPill
                      tone={info.tone}
                      label={info.label}
                      className="shrink-0 px-2 py-0.5 text-[10px]"
                    />
                  </div>
                  <p className="mt-1 truncate text-[11.5px] text-foreground/80">{person.position}</p>
                  <div className="mt-1.5 flex items-center justify-between text-[10.5px] text-muted-foreground">
                    <span>Vào làm {person.joinedAt}</span>
                    <span>{person.location}</span>
                  </div>
                </div>
              </div>
            );
          })}
          {rows.length === 0 && (
            <div className="flex flex-col items-center gap-2 px-6 py-14 text-center">
              <span className="flex h-11 w-11 items-center justify-center rounded-full bg-muted text-muted-foreground">
                <Users className="h-5 w-5" />
              </span>
              <p className="text-[13px] font-semibold text-foreground">Không tìm thấy nhân sự phù hợp</p>
              <p className="text-[12px] text-muted-foreground">Thử từ khóa khác hoặc xóa bộ lọc.</p>
            </div>
          )}
        </div>

        <div className="flex flex-col items-center justify-between gap-3 border-t border-border/80 px-4 py-3 sm:flex-row">
          <p className="text-[11.5px] text-muted-foreground">
            Hiển thị{" "}
            <span className="font-semibold text-foreground">
              {filtered.length === 0 ? 0 : (currentPage - 1) * PAGE_SIZE + 1}–
              {Math.min(currentPage * PAGE_SIZE, filtered.length)}
            </span>{" "}
            trên <span className="font-semibold text-foreground">{filtered.length}</span> nhân sự
          </p>
          <div className="flex items-center gap-1">
            <Button
              variant="outline"
              size="icon-sm"
              aria-label="Trang trước"
              disabled={currentPage === 1}
              onClick={() => setPage((prev) => Math.max(1, prev - 1))}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            {Array.from({ length: totalPages }).map((_, index) => (
              <button
                key={index}
                type="button"
                onClick={() => setPage(index + 1)}
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-sm text-[12px] font-medium transition-colors",
                  currentPage === index + 1
                    ? "bg-primary text-primary-foreground shadow-xs"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground",
                )}
              >
                {index + 1}
              </button>
            ))}
            <Button
              variant="outline"
              size="icon-sm"
              aria-label="Trang sau"
              disabled={currentPage === totalPages}
              onClick={() => setPage((prev) => Math.min(totalPages, prev + 1))}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>

      <div className="flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
        <Filter className="h-3.5 w-3.5" />
        Dữ liệu được đồng bộ với máy chấm công lúc 08:15 hôm nay.
      </div>
    </AppShell>
  );
};

export default Employees;
