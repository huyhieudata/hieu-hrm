import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import {
  CalendarCheck2,
  CalendarX2,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Download,
  Fingerprint,
  Timer,
} from "lucide-react";

import { AppShell } from "@/components/layout/app-shell";
import { Avatar, StatusPill } from "@/components/common/avatar";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { attendanceByDepartment, attendanceWeek, kpiTrend } from "@/data/hrm";

const records = [
  { name: "Nguyễn Minh Anh", department: "Nhân sự", checkIn: "08:02", checkOut: "17:38", hours: "8h36", status: "onTime" as const, note: "Làm tại văn phòng" },
  { name: "Trần Quốc Bảo", department: "Kỹ thuật", checkIn: "08:16", checkOut: "17:45", hours: "8h29", status: "late" as const, note: "Kẹt xe đường Vành đai 3" },
  { name: "Lê Thu Hà", department: "Marketing", checkIn: "07:55", checkOut: "17:30", hours: "8h35", status: "onTime" as const, note: "Làm tại văn phòng" },
  { name: "Phạm Đức Hiếu", department: "Kinh doanh", checkIn: "08:05", checkOut: "—", hours: "Đang làm", status: "onTime" as const, note: "Đi công tác Đà Nẵng" },
  { name: "Vũ Hoàng Lan", department: "Tài chính", checkIn: "08:00", checkOut: "17:32", hours: "8h32", status: "onTime" as const, note: "Làm tại văn phòng" },
  { name: "Bùi Khánh Vy", department: "Kinh doanh", checkIn: "—", checkOut: "—", hours: "0h", status: "absent" as const, note: "Nghỉ phép năm" },
  { name: "Ngô Tuấn Kiệt", department: "Kỹ thuật", checkIn: "07:48", checkOut: "17:50", hours: "9h02", status: "remote" as const, note: "Làm từ xa" },
  { name: "Đinh Văn Lộc", department: "Vận hành", checkIn: "08:42", checkOut: "17:20", hours: "7h38", status: "late" as const, note: "Ca sáng, vào muộn 42 phút" },
];

const statusInfo = {
  onTime: { label: "Đúng giờ", tone: "success" as const },
  late: { label: "Đi muộn", tone: "warning" as const },
  absent: { label: "Vắng mặt", tone: "destructive" as const },
  remote: { label: "Từ xa", tone: "info" as const },
};

interface ChartTooltipPayload {
  dataKey?: string;
  value?: number | string;
  color?: string;
}

const DayTooltip = ({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: ChartTooltipPayload[];
  label?: string;
}) => {
  if (!active || !payload?.length) return null;
  const labels: Record<string, string> = { onTime: "Đúng giờ", late: "Đi muộn", absent: "Vắng" };
  return (
    <div className="rounded-md border border-border bg-popover px-3 py-2 shadow-overlay">
      <p className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
        {label}
      </p>
      {payload.map((entry) => (
        <div key={entry.dataKey} className="flex items-center gap-2 text-[12px]">
          <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: entry.color }} />
          <span className="text-muted-foreground">{labels[entry.dataKey ?? ""] ?? entry.dataKey}:</span>
          <span className="tabular font-semibold text-foreground">{entry.value}</span>
        </div>
      ))}
    </div>
  );
};

const Attendance = () => {
  return (
    <AppShell>
      <PageHeader
        eyebrow="Nhân sự"
        title="Chấm công"
        description="Theo dõi giờ vào – ra, ca làm việc và tỷ lệ hiện diện của toàn bộ nhân sự."
        actions={
          <>
            <div className="flex h-9 items-center rounded-md border border-border bg-card shadow-xs">
              <button type="button" aria-label="Tháng trước" className="flex h-full w-8 items-center justify-center rounded-l-md text-muted-foreground hover:bg-muted">
                <ChevronLeft className="h-4 w-4" />
              </button>
              <span className="border-x border-border px-3 text-[12.5px] font-medium text-foreground">
                Tháng 10, 2026
              </span>
              <button type="button" aria-label="Tháng sau" className="flex h-full w-8 items-center justify-center rounded-r-md text-muted-foreground hover:bg-muted">
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
            <Button variant="outline" size="sm" className="h-9 gap-2 text-[12.5px]">
              <Download className="h-3.5 w-3.5" />
              Xuất bảng công
            </Button>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Có mặt hôm nay"
          value="212"
          unit="/ 248"
          delta={1.2}
          icon={CalendarCheck2}
          tone="primary"
          data={kpiTrend.present}
          className="animate-fade-up"
        />
        <StatCard
          label="Đi muộn / về sớm"
          value="14"
          unit="lượt"
          delta={-6.5}
          positiveIsGood={false}
          icon={Clock3}
          tone="amber"
          data={attendanceWeek.map((day) => day.late + 4)}
          className="animate-fade-up animation-delay-100"
        />
        <StatCard
          label="Vắng không phép"
          value="8"
          unit="lượt"
          delta={-2.1}
          positiveIsGood={false}
          icon={CalendarX2}
          tone="violet"
          data={attendanceWeek.map((day) => day.absent)}
          className="animate-fade-up animation-delay-200"
        />
        <StatCard
          label="Giờ làm trung bình"
          value="8h24"
          delta={0.8}
          icon={Timer}
          tone="teal"
          data={[7.9, 8.1, 8.0, 8.2, 8.3, 8.4, 8.4]}
          className="animate-fade-up animation-delay-300"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="col-span-1 overflow-hidden lg:col-span-2">
          <div className="flex flex-wrap items-start justify-between gap-3 px-5 pb-2 pt-5">
            <div>
              <h3 className="text-[15px] font-semibold leading-6 text-foreground">Chấm công theo ngày</h3>
              <p className="mt-0.5 text-[12px] text-muted-foreground">Tuần này · 26/10 – 01/11/2026</p>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-chart-1" /> Đúng giờ
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-chart-4" /> Đi muộn
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-chart-5" /> Vắng
              </span>
            </div>
          </div>
          <div className="h-[260px] w-full px-2 pb-3 pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={attendanceWeek} margin={{ top: 4, right: 12, left: 0, bottom: 0 }} barGap={4}>
                <CartesianGrid strokeDasharray="4 4" vertical={false} stroke="hsl(var(--border))" />
                <XAxis
                  dataKey="day"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  dy={8}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  width={34}
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                />
                <Tooltip content={<DayTooltip />} cursor={{ fill: "hsl(var(--primary) / 0.05)" }} />
                <Bar dataKey="onTime" stackId="a" fill="hsl(var(--chart-1))" radius={[0, 0, 0, 0]} barSize={22} />
                <Bar dataKey="late" stackId="a" fill="hsl(var(--chart-4))" radius={[0, 0, 0, 0]} barSize={22} />
                <Bar dataKey="absent" stackId="a" fill="hsl(var(--chart-5))" radius={[5, 5, 0, 0]} barSize={22} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="col-span-1 overflow-hidden">
          <div className="flex items-start justify-between gap-3 px-5 pb-3 pt-5">
            <div>
              <h3 className="text-[15px] font-semibold leading-6 text-foreground">Tỷ lệ hiện diện</h3>
              <p className="mt-0.5 text-[12px] text-muted-foreground">Theo phòng ban, hôm nay</p>
            </div>
            <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-primary/10 text-primary">
              <Fingerprint className="h-[18px] w-[18px]" strokeWidth={1.9} />
            </span>
          </div>

          <ul className="space-y-3.5 px-5 pb-5 pt-2">
            {attendanceByDepartment.map((dept) => {
              const percent = Math.round((dept.present / dept.total) * 100);
              return (
                <li key={dept.name}>
                  <div className="mb-1.5 flex items-center justify-between text-[12px]">
                    <span className="font-medium text-foreground">{dept.name}</span>
                    <span className="tabular text-muted-foreground">
                      {dept.present}/{dept.total}
                      <span className="ml-2 font-semibold text-foreground">{percent}%</span>
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-brand transition-[width] duration-700 ease-out"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </li>
              );
            })}
          </ul>

          <div className="border-t border-border bg-muted/30 px-5 py-3">
            <p className="text-[11px] leading-4 text-muted-foreground">
              <span className="font-semibold text-foreground">Mục tiêu tháng:</span> duy trì tỷ lệ hiện
              diện trên 95% ở tất cả phòng ban.
            </p>
          </div>
        </Card>
      </div>

      <Card className="overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/80 px-5 py-4">
          <div>
            <h3 className="text-[15px] font-semibold leading-6 text-foreground">Bảng chấm công chi tiết</h3>
            <p className="mt-0.5 text-[12px] text-muted-foreground">Dữ liệu cập nhật lúc 08:15 · 28/10/2026</p>
          </div>
          <Button variant="outline" size="sm" className="h-8 gap-1.5 text-[12px]">
            Duyệt giải trình
            <span className="rounded-full bg-warning-subtle px-1.5 text-[10px] font-semibold text-warning">4</span>
          </Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] border-collapse text-left">
            <thead>
              <tr className="border-b border-border/80 bg-muted/40">
                {["Nhân viên", "Giờ vào", "Giờ ra", "Tổng giờ", "Trạng thái", "Ghi chú"].map((heading, index) => (
                  <th
                    key={heading}
                    scope="col"
                    className={`h-11 px-5 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-muted-foreground ${
                      index === 5 ? "hidden lg:table-cell" : ""
                    }`}
                  >
                    {heading}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {records.map((record) => {
                const info = statusInfo[record.status];
                return (
                  <tr key={record.name} className="border-b border-border/60 transition-colors last:border-0 hover:bg-primary/[0.03]">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <Avatar name={record.name} size="md" />
                        <div>
                          <p className="text-[13px] font-medium leading-5 text-foreground">{record.name}</p>
                          <p className="text-[11px] text-muted-foreground">{record.department}</p>
                        </div>
                      </div>
                    </td>
                    <td className="tabular px-5 py-3 text-[12.5px] text-foreground/90">{record.checkIn}</td>
                    <td className="tabular px-5 py-3 text-[12.5px] text-foreground/90">{record.checkOut}</td>
                    <td className="tabular px-5 py-3 text-[12.5px] font-medium text-foreground">{record.hours}</td>
                    <td className="px-5 py-3">
                      <StatusPill tone={info.tone} label={info.label} />
                    </td>
                    <td className="hidden px-5 py-3 text-[12px] text-muted-foreground lg:table-cell">{record.note}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </AppShell>
  );
};

export default Attendance;
