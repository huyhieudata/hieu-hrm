export type EmployeeStatus = "active" | "probation" | "leave";

export interface Employee {
  id: string;
  code: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  position: string;
  status: EmployeeStatus;
  joinedAt: string;
  location: string;
  manager: string;
}

export const departments = [
  { name: "Kỹ thuật", count: 84, color: "hsl(var(--chart-1))", slug: "engineering" },
  { name: "Kinh doanh", count: 52, color: "hsl(var(--chart-2))", slug: "sales" },
  { name: "Vận hành", count: 42, color: "hsl(var(--chart-3))", slug: "operations" },
  { name: "Marketing", count: 26, color: "hsl(var(--chart-4))", slug: "marketing" },
  { name: "Tài chính", count: 24, color: "hsl(var(--chart-5))", slug: "finance" },
  { name: "Nhân sự", count: 20, color: "hsl(var(--info))", slug: "people" },
];

export const employees: Employee[] = [
  {
    id: "e1",
    code: "NV-1024",
    name: "Nguyễn Minh Anh",
    email: "minhanh.nguyen@nova.vn",
    phone: "0901 224 778",
    department: "Nhân sự",
    position: "Giám đốc Nhân sự",
    status: "active",
    joinedAt: "12/03/2019",
    location: "Hà Nội",
    manager: "Ban điều hành",
  },
  {
    id: "e2",
    code: "NV-1042",
    name: "Trần Quốc Bảo",
    email: "quocbao.tran@nova.vn",
    phone: "0912 887 331",
    department: "Kỹ thuật",
    position: "Kiến trúc sư phần mềm",
    status: "active",
    joinedAt: "04/08/2020",
    location: "Hà Nội",
    manager: "Nguyễn Minh Anh",
  },
  {
    id: "e3",
    code: "NV-1088",
    name: "Lê Thu Hà",
    email: "thuha.le@nova.vn",
    phone: "0983 552 116",
    department: "Marketing",
    position: "Trưởng phòng Thương hiệu",
    status: "active",
    joinedAt: "21/01/2021",
    location: "TP. Hồ Chí Minh",
    manager: "Nguyễn Minh Anh",
  },
  {
    id: "e4",
    code: "NV-1120",
    name: "Phạm Đức Hiếu",
    email: "duchieu.pham@nova.vn",
    phone: "0908 441 902",
    department: "Kinh doanh",
    position: "Quản lý Kinh doanh khu vực",
    status: "active",
    joinedAt: "15/06/2021",
    location: "Đà Nẵng",
    manager: "Trần Quốc Bảo",
  },
  {
    id: "e5",
    code: "NV-1156",
    name: "Vũ Hoàng Lan",
    email: "hoanglan.vu@nova.vn",
    phone: "0977 330 218",
    department: "Tài chính",
    position: "Chuyên viên Phân tích tài chính",
    status: "probation",
    joinedAt: "06/05/2026",
    location: "Hà Nội",
    manager: "Lê Thu Hà",
  },
  {
    id: "e6",
    code: "NV-1163",
    name: "Đỗ Thị Mai",
    email: "thimai.do@nova.vn",
    phone: "0934 118 664",
    department: "Vận hành",
    position: "Điều phối vận hành",
    status: "active",
    joinedAt: "18/09/2022",
    location: "Hải Phòng",
    manager: "Phạm Đức Hiếu",
  },
  {
    id: "e7",
    code: "NV-1171",
    name: "Hoàng Nhật Nam",
    email: "nhatnam.hoang@nova.vn",
    phone: "0916 774 205",
    department: "Kỹ thuật",
    position: "Kỹ sư Frontend",
    status: "active",
    joinedAt: "02/11/2022",
    location: "Hà Nội",
    manager: "Trần Quốc Bảo",
  },
  {
    id: "e8",
    code: "NV-1184",
    name: "Bùi Khánh Vy",
    email: "khanhvy.bui@nova.vn",
    phone: "0902 669 447",
    department: "Kinh doanh",
    position: "Chuyên viên Khách hàng",
    status: "leave",
    joinedAt: "27/02/2023",
    location: "TP. Hồ Chí Minh",
    manager: "Phạm Đức Hiếu",
  },
  {
    id: "e9",
    code: "NV-1205",
    name: "Ngô Tuấn Kiệt",
    email: "tuankiet.ngo@nova.vn",
    phone: "0988 512 073",
    department: "Kỹ thuật",
    position: "Kỹ sư DevOps",
    status: "active",
    joinedAt: "10/07/2023",
    location: "Hà Nội",
    manager: "Trần Quốc Bảo",
  },
  {
    id: "e10",
    code: "NV-1218",
    name: "Trịnh Phương Thảo",
    email: "phuongthao.trinh@nova.vn",
    phone: "0967 908 552",
    department: "Nhân sự",
    position: "Chuyên viên Tuyển dụng",
    status: "active",
    joinedAt: "14/03/2024",
    location: "Hà Nội",
    manager: "Nguyễn Minh Anh",
  },
  {
    id: "e11",
    code: "NV-1229",
    name: "Đinh Văn Lộc",
    email: "vanloc.dinh@nova.vn",
    phone: "0944 227 391",
    department: "Vận hành",
    position: "Trưởng ca sản xuất",
    status: "probation",
    joinedAt: "22/09/2026",
    location: "Bắc Ninh",
    manager: "Đỗ Thị Mai",
  },
  {
    id: "e12",
    code: "NV-1240",
    name: "Lý Gia Hân",
    email: "giahan.ly@nova.vn",
    phone: "0901 663 800",
    department: "Marketing",
    position: "Chuyên viên Nội dung",
    status: "active",
    joinedAt: "08/01/2025",
    location: "TP. Hồ Chí Minh",
    manager: "Lê Thu Hà",
  },
];

export const headcountTrend = [
  { month: "T11", headcount: 206, target: 205 },
  { month: "T12", headcount: 212, target: 212 },
  { month: "T1", headcount: 218, target: 218 },
  { month: "T2", headcount: 221, target: 224 },
  { month: "T3", headcount: 229, target: 230 },
  { month: "T4", headcount: 232, target: 236 },
  { month: "T5", headcount: 236, target: 242 },
  { month: "T6", headcount: 240, target: 248 },
  { month: "T7", headcount: 241, target: 248 },
  { month: "T8", headcount: 244, target: 252 },
  { month: "T9", headcount: 246, target: 254 },
  { month: "T10", headcount: 248, target: 256 },
];

export const attendanceByDepartment = [
  { name: "Kỹ thuật", present: 74, total: 84 },
  { name: "Kinh doanh", present: 44, total: 52 },
  { name: "Vận hành", present: 36, total: 42 },
  { name: "Marketing", present: 21, total: 26 },
  { name: "Tài chính", present: 20, total: 24 },
  { name: "Nhân sự", present: 17, total: 20 },
];

export const attendanceWeek = [
  { day: "T2", onTime: 208, late: 12, absent: 6 },
  { day: "T3", onTime: 214, late: 8, absent: 4 },
  { day: "T4", onTime: 206, late: 16, absent: 6 },
  { day: "T5", onTime: 218, late: 6, absent: 3 },
  { day: "T6", onTime: 199, late: 21, absent: 8 },
  { day: "T7", onTime: 84, late: 3, absent: 1 },
  { day: "CN", onTime: 0, late: 0, absent: 0 },
];

export interface LeaveRequest {
  id: string;
  name: string;
  department: string;
  type: string;
  from: string;
  to: string;
  days: number;
  reason: string;
  submitted: string;
  status: "pending" | "approved" | "rejected";
}

export const leaveRequests: LeaveRequest[] = [
  {
    id: "l1",
    name: "Bùi Khánh Vy",
    department: "Kinh doanh",
    type: "Phép năm",
    from: "26/10/2026",
    to: "30/10/2026",
    days: 5,
    reason: "Về quê giải quyết việc gia đình",
    submitted: "2 giờ trước",
    status: "pending",
  },
  {
    id: "l2",
    name: "Ngô Tuấn Kiệt",
    department: "Kỹ thuật",
    type: "Nghỉ ốm",
    from: "28/10/2026",
    to: "29/10/2026",
    days: 2,
    reason: "Khám và điều trị tại bệnh viện",
    submitted: "5 giờ trước",
    status: "pending",
  },
  {
    id: "l3",
    name: "Lý Gia Hân",
    department: "Marketing",
    type: "Việc riêng",
    from: "30/10/2026",
    to: "30/10/2026",
    days: 1,
    reason: "Tham dự lễ tốt nghiệp của em gái",
    submitted: "Hôm qua",
    status: "pending",
  },
  {
    id: "l4",
    name: "Trịnh Phương Thảo",
    department: "Nhân sự",
    type: "Phép năm",
    from: "02/11/2026",
    to: "04/11/2026",
    days: 3,
    reason: "Du lịch cùng gia đình",
    submitted: "Hôm qua",
    status: "approved",
  },
  {
    id: "l5",
    name: "Đỗ Thị Mai",
    department: "Vận hành",
    type: "Nghỉ bù",
    from: "24/10/2026",
    to: "24/10/2026",
    days: 1,
    reason: "Nghỉ bù ca trực cuối tuần trước",
    submitted: "23/10/2026",
    status: "approved",
  },
  {
    id: "l6",
    name: "Hoàng Nhật Nam",
    department: "Kỹ thuật",
    type: "Phép năm",
    from: "20/10/2026",
    to: "21/10/2026",
    days: 2,
    reason: "Trùng lịch release quan trọng",
    submitted: "18/10/2026",
    status: "rejected",
  },
];

export const leaveBalance = [
  { name: "Nguyễn Minh Anh", total: 18, used: 6 },
  { name: "Trần Quốc Bảo", total: 18, used: 11 },
  { name: "Lê Thu Hà", total: 18, used: 4 },
  { name: "Phạm Đức Hiếu", total: 18, used: 9 },
  { name: "Đỗ Thị Mai", total: 18, used: 13 },
];

export interface PayrollRow {
  id: string;
  name: string;
  department: string;
  position: string;
  base: number;
  allowance: number;
  deduction: number;
  status: "paid" | "processing" | "draft";
}

export const payrollRows: PayrollRow[] = [
  {
    id: "p1",
    name: "Nguyễn Minh Anh",
    department: "Nhân sự",
    position: "Giám đốc Nhân sự",
    base: 62000000,
    allowance: 8000000,
    deduction: 9200000,
    status: "paid",
  },
  {
    id: "p2",
    name: "Trần Quốc Bảo",
    department: "Kỹ thuật",
    position: "Kiến trúc sư phần mềm",
    base: 54000000,
    allowance: 6000000,
    deduction: 7800000,
    status: "paid",
  },
  {
    id: "p3",
    name: "Lê Thu Hà",
    department: "Marketing",
    position: "Trưởng phòng Thương hiệu",
    base: 42000000,
    allowance: 4500000,
    deduction: 6100000,
    status: "processing",
  },
  {
    id: "p4",
    name: "Phạm Đức Hiếu",
    department: "Kinh doanh",
    position: "Quản lý Kinh doanh khu vực",
    base: 38500000,
    allowance: 9000000,
    deduction: 6200000,
    status: "processing",
  },
  {
    id: "p5",
    name: "Đỗ Thị Mai",
    department: "Vận hành",
    position: "Điều phối vận hành",
    base: 24000000,
    allowance: 2500000,
    deduction: 3400000,
    status: "draft",
  },
  {
    id: "p6",
    name: "Hoàng Nhật Nam",
    department: "Kỹ thuật",
    position: "Kỹ sư Frontend",
    base: 32000000,
    allowance: 2000000,
    deduction: 4300000,
    status: "processing",
  },
  {
    id: "p7",
    name: "Trịnh Phương Thảo",
    department: "Nhân sự",
    position: "Chuyên viên Tuyển dụng",
    base: 19000000,
    allowance: 1500000,
    deduction: 2600000,
    status: "draft",
  },
];

export const upcomingBirthdays = [
  { name: "Vũ Hoàng Lan", date: "30/10", department: "Tài chính" },
  { name: "Ngô Tuấn Kiệt", date: "02/11", department: "Kỹ thuật" },
  { name: "Lê Thu Hà", date: "05/11", department: "Marketing" },
];

export const recentActivity = [
  {
    id: "a1",
    title: "Đinh Văn Lộc đã hoàn tất hồ sơ nhân sự",
    meta: "Vận hành · 12 phút trước",
    tone: "success" as const,
  },
  {
    id: "a2",
    title: "Bảng lương tháng 10 đã được tạo nháp",
    meta: "Tài chính · 1 giờ trước",
    tone: "info" as const,
  },
  {
    id: "a3",
    title: "2 ứng viên mới vào vòng phỏng vấn kỹ thuật",
    meta: "Tuyển dụng · 3 giờ trước",
    tone: "warning" as const,
  },
];

export const kpiTrend = {
  headcount: [232, 236, 240, 241, 244, 246, 248],
  present: [198, 204, 209, 206, 214, 211, 212],
  pending: [8, 11, 9, 14, 12, 10, 12],
  payroll: [3.42, 3.51, 3.6, 3.68, 3.74, 3.8, 3.84],
};
