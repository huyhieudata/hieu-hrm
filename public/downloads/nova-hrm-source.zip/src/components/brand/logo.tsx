import { cn } from "@/lib/utils";

export const LogoMark = ({ className }: { className?: string }) => (
  <div
    className={cn(
      "relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-[12px] bg-brand shadow-primary-glow",
      className,
    )}
  >
    <div className="absolute inset-0 bg-sheen opacity-15" />
    <svg viewBox="0 0 24 24" fill="none" className="relative h-[21px] w-[21px] text-primary-foreground">
      <path
        d="M6.5 17.5v-11l11 11v-11"
        stroke="currentColor"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  </div>
);

interface LogoProps {
  collapsed?: boolean;
  className?: string;
  subtitle?: string;
}

export const Logo = ({ collapsed = false, className, subtitle = "People Platform" }: LogoProps) => (
  <div className={cn("flex items-center gap-2.5", className)}>
    <LogoMark />
    {!collapsed && (
      <div className="flex flex-col">
        <span className="font-display text-[17px] font-semibold leading-5 tracking-tight text-foreground">
          Nova<span className="text-primary">HRM</span>
        </span>
        <span className="text-[10px] font-medium uppercase leading-4 tracking-[0.16em] text-muted-foreground">
          {subtitle}
        </span>
      </div>
    )}
  </div>
);
