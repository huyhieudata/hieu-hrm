import { useNavigate, useLocation } from "react-router-dom";
import {
  Bell,
  Building2,
  ChevronDown,
  Command,
  HelpCircle,
  LogOut,
  Menu,
  Search,
  ShieldCheck,
  Sparkles,
} from "lucide-react";

import { Avatar } from "@/components/common/avatar";
import { LogoMark } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { displayName, useAuth } from "@/lib/auth-provider";
import { useCompany } from "@/lib/company-provider";
import { ROLE_LABELS } from "@/lib/roles";

const routeMeta: Record<string, { group: string; label: string }> = {
  "/": { group: "Không gian làm việc", label: "Bảng điều khiển" },
  "/employees": { group: "Nhân sự", label: "Hồ sơ nhân viên" },
  "/attendance": { group: "Nhân sự", label: "Chấm công" },
  "/leave": { group: "Nhân sự", label: "Nghỉ phép" },
  "/payroll": { group: "Tài chính", label: "Bảng lương" },
  "/doi-ngu": { group: "Quản trị", label: "Đội ngũ & phân quyền" },
};

interface AppTopbarProps {
  onOpenSidebar: () => void;
}

export const AppTopbar = ({ onOpenSidebar }: AppTopbarProps) => {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { profile, user, signOut } = useAuth();
  const { activeCompany, role } = useCompany();
  const meta = routeMeta[pathname] ?? routeMeta["/"];

  const name = displayName(profile, user?.email);

  const handleSignOut = async () => {
    await signOut();
    navigate("/login", { replace: true });
  };

  return (
    <header className="sticky top-0 z-30 border-b border-border/70 bg-background/85 backdrop-blur-xl">
      <div className="flex h-16 items-center gap-3 px-4 sm:px-6 xl:px-8">
        <button
          type="button"
          onClick={onOpenSidebar}
          aria-label="Mở menu điều hướng"
          className="flex h-9 w-9 items-center justify-center rounded-sm border border-border bg-card text-foreground shadow-soft transition-colors hover:bg-muted lg:hidden"
        >
          <Menu className="h-4 w-4" />
        </button>

        <div className="flex items-center gap-2 lg:hidden">
          <LogoMark className="h-8 w-8 rounded-[10px]" />
          <span className="font-display text-[15px] font-semibold tracking-tight text-foreground">
            Nova<span className="text-primary">HRM</span>
          </span>
        </div>

        <div className="hidden min-w-0 shrink-0 items-center gap-2 whitespace-nowrap text-[12.5px] xl:flex">
          <span className="shrink-0 text-muted-foreground">{meta.group}</span>
          <span className="text-border">/</span>
          <span className="truncate font-semibold text-foreground">{meta.label}</span>
          {activeCompany && (
            <>
              <span className="text-border">·</span>
              <span className="truncate rounded-full bg-muted px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
                {activeCompany.name}
              </span>
            </>
          )}
        </div>

        <div className="ml-auto flex items-center gap-2">
          <label className="group relative hidden md:block">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              placeholder="Tìm nhân viên, mã NV, phòng ban…"
              className="h-9 w-[210px] rounded-md border border-border bg-card pl-9 pr-16 text-[13px] text-foreground shadow-xs outline-none transition-all duration-200 placeholder:text-muted-foreground/80 hover:border-primary/30 focus:w-[280px] focus:border-primary focus:shadow-focus xl:w-[280px] xl:focus:w-[320px]"
            />
            <kbd className="pointer-events-none absolute right-2.5 top-1/2 flex -translate-y-1/2 items-center gap-0.5 rounded border border-border bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
              <Command className="h-2.5 w-2.5" />K
            </kbd>
          </label>

          <Button
            variant="outline"
            size="sm"
            className="hidden gap-1.5 border-primary/25 bg-primary-subtle text-primary-subtle-foreground hover:bg-primary/15 hover:text-primary-subtle-foreground sm:flex"
          >
            <Sparkles className="h-3.5 w-3.5" />
            Nova AI
          </Button>

          <Button
            variant="ghost"
            size="icon"
            aria-label="Trợ giúp"
            className="hidden text-muted-foreground sm:flex"
          >
            <HelpCircle className="h-[18px] w-[18px]" />
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                aria-label="Thông báo"
                className="flex h-9 w-9 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:shadow-focus"
              >
                <Bell className="h-[18px] w-[18px]" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[320px] rounded-lg p-0 shadow-overlay">
              <div className="border-b border-border px-4 py-3">
                <p className="text-sm font-semibold text-foreground">Thông báo</p>
              </div>
              <div className="px-4 py-8 text-center">
                <Bell className="mx-auto h-5 w-5 text-muted-foreground" />
                <p className="mt-2 text-[12.5px] font-medium text-foreground">Chưa có thông báo mới</p>
                <p className="mt-1 text-[11.5px] leading-5 text-muted-foreground">
                  Các hoạt động của đội ngũ sẽ xuất hiện tại đây.
                </p>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="mx-0.5 hidden h-6 w-px bg-border sm:block" />

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                className="flex items-center gap-2.5 rounded-md py-1 pl-1 pr-1.5 transition-colors hover:bg-muted focus-visible:shadow-focus"
              >
                <Avatar name={name} size="md" className="ring-0" />
                <span className="hidden text-left lg:block">
                  <span className="block max-w-[160px] truncate text-[12.5px] font-semibold leading-4 text-foreground">
                    {name}
                  </span>
                  <span className="block text-[10.5px] text-muted-foreground">
                    {role ? ROLE_LABELS[role] : "Chưa có vai trò"}
                  </span>
                </span>
                <ChevronDown className="hidden h-3.5 w-3.5 text-muted-foreground lg:block" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[250px] rounded-lg shadow-overlay">
              <DropdownMenuLabel className="flex items-center gap-2.5 py-2.5">
                <Avatar name={name} size="md" />
                <span className="min-w-0">
                  <span className="block truncate text-[12.5px] font-semibold text-foreground">{name}</span>
                  <span className="block truncate text-[11px] font-normal text-muted-foreground">
                    {user?.email}
                  </span>
                </span>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="gap-2.5" onSelect={() => navigate("/doi-ngu")}>
                <ShieldCheck className="h-4 w-4" /> Đội ngũ & phân quyền
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2.5" onSelect={() => navigate("/cong-ty")}>
                <Building2 className="h-4 w-4" /> Chuyển công ty
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                className="gap-2.5 text-destructive focus:bg-destructive-subtle focus:text-destructive"
                onSelect={() => void handleSignOut()}
              >
                <LogOut className="h-4 w-4" /> Đăng xuất
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
};
