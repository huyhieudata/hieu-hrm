import { CalendarClock, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

const present = 212;
const total = 248;
const percentage = Math.round((present / total) * 100);
const radius = 54;
const circumference = 2 * Math.PI * radius;

const metrics = [
  { label: "Đúng giờ", value: 198, tone: "text-success", dot: "bg-success" },
  { label: "Đi muộn", value: 14, tone: "text-warning", dot: "bg-warning" },
  { label: "Vắng mặt", value: 8, tone: "text-destructive", dot: "bg-destructive" },
  { label: "Làm từ xa", value: 14, tone: "text-info", dot: "bg-info" },
];

const shifts = [
  { name: "Ca sáng", time: "08:00 – 12:00", filled: 206, total: 214, tone: "success" as const },
  { name: "Ca chiều", time: "13:30 – 17:30", filled: 198, total: 214, tone: "success" as const },
  { name: "Ca tối", time: "18:00 – 21:00", filled: 22, total: 34, tone: "warning" as const },
];

const toneMap = {
  success: "bg-success-subtle text-success",
  warning: "bg-warning-subtle text-warning",
};

export const AttendanceToday = () => (
  <Card className="col-span-1 flex flex-col overflow-hidden">
    <div className="flex items-start justify-between gap-3 px-5 pb-1 pt-5">
      <div>
        <h3 className="text-[15px] font-semibold leading-6 text-foreground">Chấm công hôm nay</h3>
        <p className="mt-0.5 text-[12px] text-muted-foreground">Thứ Tư, 28/10/2026</p>
      </div>
      <span className="inline-flex items-center gap-1.5 rounded-full bg-success-subtle px-2 py-1 text-[10px] font-semibold text-success">
        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-success" />
        Trực tiếp
      </span>
    </div>

    <div className="flex items-center gap-3 px-5 pb-4 pt-3">
      <div className="relative h-[118px] w-[118px] shrink-0">
        <svg viewBox="0 0 132 132" className="h-full w-full -rotate-90">
          <circle
            cx="66"
            cy="66"
            r={radius}
            fill="none"
            stroke="hsl(var(--muted))"
            strokeWidth="9"
          />
          <defs>
            <linearGradient id="attendanceGauge" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="hsl(var(--chart-1))" />
              <stop offset="100%" stopColor="hsl(var(--chart-2))" />
            </linearGradient>
          </defs>
          <circle
            cx="66"
            cy="66"
            r={radius}
            fill="none"
            stroke="url(#attendanceGauge)"
            strokeWidth="9"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={circumference * (1 - percentage / 100)}
            className="transition-[stroke-dashoffset] duration-700 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="tabular font-display text-[26px] font-semibold leading-8 text-foreground">
            {percentage}%
          </span>
          <span className="text-[10.5px] text-muted-foreground">
            {present}/{total} có mặt
          </span>
        </div>
      </div>

      <div className="grid flex-1 grid-cols-2 gap-x-2 gap-y-3">
        {metrics.map((metric) => (
          <div key={metric.label} className="min-w-0">
            <div className="flex items-center gap-1">
              <span className={cn("h-1.5 w-1.5 shrink-0 rounded-full", metric.dot)} />
              <span className="truncate whitespace-nowrap text-[10px] text-muted-foreground">
                {metric.label}
              </span>
            </div>
            <p className="tabular mt-0.5 font-display text-[16px] font-semibold leading-5 text-foreground">
              {metric.value}
            </p>
          </div>
        ))}
      </div>
    </div>

    <div className="mt-auto border-t border-border bg-muted/30 px-5 py-4">
      <div className="mb-2.5 flex items-center justify-between">
        <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
          Ca làm việc
        </p>
        <CalendarClock className="h-3.5 w-3.5 text-muted-foreground" />
      </div>
      <ul className="space-y-2">
        {shifts.map((shift) => (
          <li key={shift.name} className="flex items-center gap-2.5">
            <span className="w-[58px] shrink-0 text-[12px] font-medium text-foreground">
              {shift.name}
            </span>
            <span className="tabular flex-1 text-[11px] text-muted-foreground">{shift.time}</span>
            <span
              className={cn(
                "tabular rounded-full px-1.5 py-0.5 text-[10px] font-semibold",
                toneMap[shift.tone],
              )}
            >
              {shift.filled}/{shift.total}
            </span>
          </li>
        ))}
      </ul>
      <Link
        to="/attendance"
        className="mt-3 inline-flex items-center gap-1 text-[11.5px] font-semibold text-primary transition-colors hover:text-primary-hover"
      >
        Xem bảng chấm công
        <ChevronRight className="h-3 w-3" />
      </Link>
    </div>
  </Card>
);
