import { useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { CalendarDays, Check, ChevronRight, Clock3, X } from "lucide-react";

import { Avatar, StatusPill } from "@/components/common/avatar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { leaveRequests as seed, type LeaveRequest } from "@/data/hrm";

const typeTone: Record<string, "primary" | "info" | "warning" | "muted"> = {
  "Phép năm": "primary",
  "Nghỉ ốm": "info",
  "Việc riêng": "warning",
  "Nghỉ bù": "muted",
};

export const LeaveApprovals = () => {
  const [requests, setRequests] = useState<LeaveRequest[]>(seed);
  const pending = requests.filter((item) => item.status === "pending");

  const handle = (id: string, approve: boolean) => {
    const target = requests.find((item) => item.id === id);
    setRequests((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, status: approve ? "approved" : "rejected" } : item,
      ),
    );
    if (!target) return;
    if (approve) {
      toast.success("Đã duyệt đơn nghỉ phép", { description: `${target.name} · ${target.days} ngày` });
    } else {
      toast.error("Đã từ chối đơn nghỉ phép", { description: `${target.name} · ${target.days} ngày` });
    }
  };

  return (
    <Card className="col-span-1 flex flex-col overflow-hidden lg:col-span-2">
      <div className="flex flex-wrap items-start justify-between gap-3 px-5 pb-3 pt-5">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-[15px] font-semibold leading-6 text-foreground">Đơn nghỉ phép chờ duyệt</h3>
            <span className="tabular flex h-5 min-w-5 items-center justify-center rounded-full bg-primary-subtle px-1.5 text-[10.5px] font-semibold text-primary-subtle-foreground">
              {pending.length}
            </span>
          </div>
          <p className="mt-0.5 text-[12px] text-muted-foreground">
            Ưu tiên xử lý để không ảnh hưởng bảng lương tháng 10
          </p>
        </div>
        <Link
          to="/leave"
          className="inline-flex items-center gap-1 rounded-sm px-2 py-1 text-[12px] font-semibold text-primary transition-colors hover:bg-primary-subtle"
        >
          Xem tất cả
          <ChevronRight className="h-3.5 w-3.5" />
        </Link>
      </div>

      {pending.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-2 px-6 py-14 text-center">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-success-subtle text-success">
            <Check className="h-5 w-5" />
          </span>
          <p className="text-[13px] font-semibold text-foreground">Đã xử lý hết đơn hôm nay</p>
          <p className="text-[12px] text-muted-foreground">Mọi đơn nghỉ phép đã được phản hồi.</p>
        </div>
      ) : (
        <ul className="divide-y divide-border/80">
          {pending.map((item) => (
            <li
              key={item.id}
              className="group flex flex-col gap-3 px-5 py-3.5 transition-colors hover:bg-muted/40 sm:flex-row sm:items-center"
            >
              <div className="flex min-w-0 flex-1 items-start gap-3">
                <Avatar name={item.name} size="lg" />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                    <p className="truncate text-[13px] font-semibold text-foreground">{item.name}</p>
                    <span className="text-[11px] text-muted-foreground">· {item.department}</span>
                    <StatusPill
                      label={item.type}
                      tone={typeTone[item.type] ?? "muted"}
                      dot={false}
                      className="px-2 py-0 text-[10px]"
                    />
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11.5px] text-muted-foreground">
                    <span className="inline-flex items-center gap-1">
                      <CalendarDays className="h-3 w-3" />
                      {item.from} – {item.to}
                    </span>
                    <span className="tabular font-medium text-foreground/80">{item.days} ngày</span>
                    <span className="inline-flex items-center gap-1 text-muted-foreground/80">
                      <Clock3 className="h-3 w-3" />
                      {item.submitted}
                    </span>
                  </div>
                  <p className="mt-1 line-clamp-1 text-[11.5px] italic text-muted-foreground/90">
                    “{item.reason}”
                  </p>
                </div>
              </div>

              <div className="flex shrink-0 items-center gap-1.5 pl-12 sm:pl-0">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 gap-1 px-2.5 text-destructive hover:bg-destructive-subtle hover:text-destructive"
                  onClick={() => handle(item.id, false)}
                >
                  <X className="h-3.5 w-3.5" />
                  Từ chối
                </Button>
                <Button
                  size="sm"
                  className="h-8 gap-1 px-2.5"
                  onClick={() => handle(item.id, true)}
                >
                  <Check className="h-3.5 w-3.5" />
                  Duyệt
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <div className="mt-auto flex items-center justify-between border-t border-border bg-muted/30 px-5 py-3">
        <p className="text-[11.5px] text-muted-foreground">
          Đơn được duyệt sẽ tự động cập nhật số dư phép và bảng lương.
        </p>
        <span className="hidden items-center gap-1 text-[11px] font-medium text-primary sm:flex">
          SLA 24 giờ
        </span>
      </div>
    </Card>
  );
};
