import { ArrowUpRight, Cake, CalendarPlus, PartyPopper } from "lucide-react";

import { Avatar } from "@/components/common/avatar";
import { Card } from "@/components/ui/card";
import { upcomingBirthdays } from "@/data/hrm";

export const BirthdaysCard = () => (
  <Card className="col-span-1 overflow-hidden">
    <div className="flex items-start justify-between gap-3 px-5 pb-3 pt-5">
      <div>
        <h3 className="text-[15px] font-semibold leading-6 text-foreground">Sinh nhật &amp; sự kiện</h3>
        <p className="mt-0.5 text-[12px] text-muted-foreground">7 ngày tới tại Nova Group</p>
      </div>
      <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-chart-5/12 text-chart-5">
        <PartyPopper className="h-[18px] w-[18px]" strokeWidth={1.9} />
      </span>
    </div>

    <ul className="divide-y divide-border/80 px-2">
      {upcomingBirthdays.map((person) => {
        const [day, month] = person.date.split("/");
        return (
          <li
            key={person.name}
            className="group flex items-center gap-3 rounded-md px-3 py-3 transition-colors hover:bg-muted/50"
          >
            <div className="flex h-10 w-10 shrink-0 flex-col items-center justify-center rounded-[10px] border border-border bg-muted/50">
              <span className="tabular font-display text-[14px] font-semibold leading-4 text-foreground">
                {day}
              </span>
              <span className="text-[9px] uppercase leading-3 text-muted-foreground">Th{month}</span>
            </div>
            <Avatar name={person.name} size="md" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13px] font-medium text-foreground">{person.name}</p>
              <p className="truncate text-[11px] text-muted-foreground">{person.department}</p>
            </div>
            <button
              type="button"
              className="flex h-8 items-center gap-1 rounded-sm border border-border bg-card px-2.5 text-[11px] font-semibold text-muted-foreground opacity-0 transition-all hover:border-primary/30 hover:text-primary group-hover:opacity-100 focus-visible:opacity-100"
            >
              <Cake className="h-3.5 w-3.5" />
              Chúc
            </button>
          </li>
        );
      })}
    </ul>

    <div className="border-t border-border bg-muted/30 px-5 py-3">
      <button
        type="button"
        className="flex w-full items-center justify-between text-[11.5px] font-semibold text-primary"
      >
        <span className="inline-flex items-center gap-1.5">
          <CalendarPlus className="h-3.5 w-3.5" />
          Tạo sự kiện nội bộ
        </span>
        <ArrowUpRight className="h-3.5 w-3.5" />
      </button>
    </div>
  </Card>
);
