import { Cell, Pie, PieChart, ResponsiveContainer } from "recharts";
import { ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";

import { Card } from "@/components/ui/card";
import { departments } from "@/data/hrm";

const total = departments.reduce((sum, item) => sum + item.count, 0);

export const DepartmentBreakdown = () => (
  <Card className="col-span-1 flex flex-col overflow-hidden">
    <div className="flex items-start justify-between gap-3 px-5 pb-1 pt-5">
      <div>
        <h3 className="text-[15px] font-semibold leading-6 text-foreground">Cơ cấu phòng ban</h3>
        <p className="mt-0.5 text-[12px] text-muted-foreground">Phân bổ nhân sự theo bộ phận</p>
      </div>
      <Link
        to="/employees"
        className="flex h-8 w-8 items-center justify-center rounded-sm text-muted-foreground transition-colors hover:bg-muted hover:text-primary"
        aria-label="Xem chi tiết phòng ban"
      >
        <ArrowUpRight className="h-4 w-4" />
      </Link>
    </div>

    <div className="relative mx-auto mt-1 h-[168px] w-full max-w-[240px]">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={departments}
            dataKey="count"
            nameKey="name"
            innerRadius={56}
            outerRadius={80}
            paddingAngle={3}
            cornerRadius={6}
            stroke="none"
            startAngle={90}
            endAngle={-270}
          >
            {departments.map((item) => (
              <Cell key={item.slug} fill={item.color} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
        <span className="tabular font-display text-[26px] font-semibold leading-8 text-foreground">
          {total}
        </span>
        <span className="text-[11px] text-muted-foreground">nhân sự</span>
      </div>
    </div>

    <div className="grid flex-1 grid-cols-2 gap-x-3 gap-y-2.5 px-5 pb-5 pt-3">
      {departments.map((item) => (
        <div key={item.slug} className="flex items-center gap-2">
          <span
            className="h-2 w-2 shrink-0 rounded-full"
            style={{ backgroundColor: item.color }}
          />
          <span className="min-w-0 flex-1 truncate text-[12px] text-muted-foreground">
            {item.name}
          </span>
          <span className="tabular text-[12px] font-semibold text-foreground">{item.count}</span>
        </div>
      ))}
    </div>
  </Card>
);
