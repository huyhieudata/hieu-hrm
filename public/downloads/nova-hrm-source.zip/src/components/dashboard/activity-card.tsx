import { BadgeCheck, Banknote, CalendarCheck2, ChevronRight } from "lucide-react";

import { Card } from "@/components/ui/card";
import { recentActivity } from "@/data/hrm";
import { cn } from "@/lib/utils";

const iconMap = {
  success: { icon: BadgeCheck, className: "bg-success-subtle text-success" },
  info: { icon: Banknote, className: "bg-info-subtle text-info" },
  warning: { icon: CalendarCheck2, className: "bg-warning-subtle text-warning" },
};

export const ActivityCard = () => (
  <Card className="col-span-1 overflow-hidden">
    <div className="flex items-start justify-between gap-3 px-5 pb-3 pt-5">
      <div>
        <h3 className="text-[15px] font-semibold leading-6 text-foreground">Hoạt động gần đây</h3>
        <p className="mt-0.5 text-[12px] text-muted-foreground">Nhật ký thay đổi trong hệ thống</p>
      </div>
      <button
        type="button"
        className="inline-flex items-center gap-1 rounded-sm px-2 py-1 text-[12px] font-semibold text-primary transition-colors hover:bg-primary-subtle"
      >
        Tất cả
        <ChevronRight className="h-3.5 w-3.5" />
      </button>
    </div>

    <ul className="px-5 pb-2">
      {recentActivity.map((item, index) => {
        const style = iconMap[item.tone];
        const Icon = style.icon;
        return (
          <li key={item.id} className="relative flex gap-3 pb-4 last:pb-2">
            {index !== recentActivity.length - 1 && (
              <span className="absolute left-[17px] top-9 h-[calc(100%-20px)] w-px bg-border" />
            )}
            <span
              className={cn(
                "relative flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px]",
                style.className,
              )}
            >
              <Icon className="h-4 w-4" strokeWidth={1.9} />
            </span>
            <div className="min-w-0 flex-1 pt-0.5">
              <p className="text-[12.5px] font-medium leading-5 text-foreground">{item.title}</p>
              <p className="mt-0.5 text-[11px] text-muted-foreground">{item.meta}</p>
            </div>
          </li>
        );
      })}
    </ul>

    <div className="mx-5 mb-5 mt-1 rounded-md border border-dashed border-border bg-muted/30 px-3 py-2.5">
      <p className="text-[11px] leading-4 text-muted-foreground">
        <span className="font-semibold text-foreground">Gợi ý:</span> bật nhắc nhở tự động để không bỏ lỡ
        hồ sơ chờ duyệt.
      </p>
    </div>
  </Card>
);
