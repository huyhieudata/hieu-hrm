import { useState } from "react";
import {
  Area,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { TrendingUp } from "lucide-react";

import { Card } from "@/components/ui/card";
import { headcountTrend } from "@/data/hrm";
import { cn } from "@/lib/utils";

interface TooltipPayload {
  name?: string;
  value?: number | string;
  color?: string;
  dataKey?: string;
}

const TrendTooltip = ({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
}) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-md border border-border bg-popover px-3 py-2 shadow-overlay">
      <p className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
        Tháng {label}
      </p>
      {payload.map((entry) => (
        <div key={entry.dataKey} className="flex items-center gap-2 text-[12px]">
          <span
            className="h-1.5 w-1.5 rounded-full"
            style={{ backgroundColor: entry.color }}
          />
          <span className="text-muted-foreground">
            {entry.dataKey === "headcount" ? "Nhân sự" : "Mục tiêu"}:
          </span>
          <span className="tabular font-semibold text-foreground">{entry.value}</span>
        </div>
      ))}
    </div>
  );
};

const ranges = [
  { label: "6 tháng", value: 6 },
  { label: "12 tháng", value: 12 },
];

export const HeadcountChart = () => {
  const [months, setMonths] = useState(12);
  const data = headcountTrend.slice(-months);
  const growth = ((248 - 198) / 198) * 100;

  return (
    <Card className="col-span-1 flex flex-col overflow-hidden lg:col-span-2">
      <div className="flex flex-wrap items-start justify-between gap-3 px-5 pb-2 pt-5">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-[15px] font-semibold leading-6 text-foreground">Biến động nhân sự</h3>
            <span className="inline-flex items-center gap-1 rounded-full bg-success-subtle px-1.5 py-0.5 text-[10px] font-semibold text-success">
              <TrendingUp className="h-2.5 w-2.5" />+{growth.toFixed(1)}%
            </span>
          </div>
          <p className="mt-0.5 text-[12px] text-muted-foreground">
            Tổng số nhân sự so với kế hoạch tuyển dụng
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden items-center gap-3 text-[11px] text-muted-foreground sm:flex">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-chart-1" /> Thực tế
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-chart-2" /> Mục tiêu
            </span>
          </div>
          <div className="flex items-center gap-0.5 rounded-md border border-border bg-muted/60 p-0.5">
            {ranges.map((range) => (
              <button
                key={range.value}
                type="button"
                onClick={() => setMonths(range.value)}
                className={cn(
                  "rounded-[7px] px-2.5 py-1 text-[11px] font-medium transition-all",
                  months === range.value
                    ? "bg-card font-semibold text-foreground shadow-xs"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                {range.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-2 h-[248px] w-full pr-4">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 12, right: 8, left: 4, bottom: 0 }}>
            <defs>
              <linearGradient id="headcountFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="hsl(var(--chart-1))" stopOpacity={0.22} />
                <stop offset="100%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid
              strokeDasharray="4 4"
              vertical={false}
              stroke="hsl(var(--border))"
            />
            <XAxis
              dataKey="month"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
              dy={8}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              width={38}
              domain={[190, 265]}
              ticks={[200, 220, 240, 260]}
              tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
            />
            <Tooltip
              content={<TrendTooltip />}
              cursor={{ stroke: "hsl(var(--primary) / 0.35)", strokeWidth: 1.5, strokeDasharray: "4 4" }}
            />
            <Area
              type="monotone"
              dataKey="headcount"
              stroke="hsl(var(--chart-1))"
              strokeWidth={2.4}
              fill="url(#headcountFill)"
              activeDot={{ r: 4, strokeWidth: 2, stroke: "hsl(var(--card))" }}
            />
            <Line
              type="monotone"
              dataKey="target"
              stroke="hsl(var(--chart-2))"
              strokeWidth={1.8}
              strokeDasharray="5 5"
              dot={false}
              activeDot={{ r: 3.5, strokeWidth: 2, stroke: "hsl(var(--card))" }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
};
